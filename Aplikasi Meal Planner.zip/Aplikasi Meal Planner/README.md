# NutriPlan Green - Aplikasi Web Meal Planner Diet Sehat 🌱

Aplikasi web modern untuk perencanaan menu diet sehat, kalkulator kebutuhan kalori harian presisi (TDEE & BMR), meal planning mingguan dan bulanan, generator daftar belanja otomatis, serta fitur ekspor dokumen ke PDF. Dirancang dengan antarmuka bertema hijau modern (*fresh emerald & mint*) dan responsif untuk perangkat mobile maupun desktop.

---

## 🌟 Fitur Utama

1. **Desain Modern Hijau & Mobile-Friendly:**
   - Palet warna hijau segar (*emerald*, *mint*, *sage*) yang estetik, bersih, dan nyaman di mata.
   - Antarmuka responsif dengan *bottom navigation bar* khusus mobile dan navigasi atas untuk desktop.
   - Kartu makanan interaktif dengan micro-interactions, badge nutrisi, dan animasi perayaan saat target tercapai.

2. **Registrasi & Login Member (Autentikasi Lokal):**
   - Form Registrasi member baru dan Login dengan validasi.
   - Dukungan sesi persisten via `localStorage`.
   - Tombol **Masuk Cepat Akun Demo** (`demo@nutriplan.id` / `password123` atas nama Sarah Wijaya).
   - Opsi eksplorasi langsung melalui **Mode Tamu (Guest Mode)**.
   - Manajemen profil kesehatan pengguna dengan avatar dinamis.

3. **Kalkulator Kebutuhan Kalori (TDEE, BMR, & BMI):**
   - Berdasarkan rumus ilmiah emas **Mifflin-St Jeor**.
   - Input lengkap: Jenis kelamin, Usia, Berat Badan (kg), Tinggi Badan (cm), dan 5 tingkat aktivitas fisik.
   - Pilihan target diet: Defisit kalori sehat (-500 kcal), Defisit cepat (-750 kcal), Maintenance (pertahankan berat), dan Surplus massa otot (+400 kcal).
   - Perhitungan rasio makronutrien seimbang: Karbohidrat kompleks (45%), Protein tinggi (30%), Lemak sehat (25%).
   - Tombol *"Terapkan ke Meal Plan"* untuk menyelaraskan target kalori secara instan ke rencana harian.

4. **Meal Plan Mingguan & Bulanan (Interactive Planner):**
   - **Mode Mingguan:** Navigasi 7 hari (Senin s/d Minggu) dengan visual tracker kalori vs target.
   - **Mode Bulanan:** Kalender ikhtisar 4 pekan penuh dengan rata-rata kalori per pekan.
   - Pembagian 4 waktu makan harian:
     - 🌅 **Sarapan** (*Breakfast*)
     - ☀️ **Makan Siang** (*Lunch*)
     - 🌙 **Makan Malam** (*Dinner*)
     - 🍎 **Camilan Sehat** (*Healthy Snack*)
   - **Fitur Interaktif:**
     - Centang makanan yang sudah dikonsumsi (*Meal Tracker*).
     - **Ganti Menu (Swap Meal):** Pilih resep alternatif dari 32 resep sehat yang tersedia.
     - **Detail Resep Lengkap:** Foto berkualitas tinggi, daftar bahan, dan instruksi memasak langkah demi langkah.

5. **Daftar Belanja Otomatis (Smart Grocery List):**
   - Secara otomatis menghitung dan mengumpulkan seluruh bahan dari menu aktif pada meal plan (pilihan: Pekan Ini atau Sebulan Penuh).
   - Pengelompokan cerdas dalam 5 kategori:
     - 🥬 *Sayuran & Buah Segar*
     - 🥩 *Sumber Protein (Ayam, Ikan, Daging, Telur, Tahu)*
     - 🌾 *Karbohidrat & Biji-Bijian Sehat*
     - 🥛 *Susu & Alternatif Nabati*
     - 🫒 *Bumbu, Saus & Minyak Sehat*
   - Checkbox interaktif untuk menandai barang yang sudah dibeli dengan indikator progres belanja.
   - Fitur **Tambah Bahan Manual** untuk kebutuhan belanja pribadi di luar menu.
   - Tombol **Reset Checklist**.

6. **Fitur Ekspor PDF:**
   - **Ekspor Jadwal Meal Plan ke PDF:** Dokumen format cetak A4 profesional dengan header hijau NutriPlan, profil member, ringkasan target kalori, dan tabel menu harian.
   - **Ekspor Daftar Belanja ke PDF:** Format checklist 2-kolom ringkas dan rapi, siap dibawa belanja ke supermarket atau pasar.
   - Dukungan cetak browser langsung (`Ctrl+P` / `Cmd+P`) dengan stylesheet `@media print` yang rapi tanpa tombol navigasi.

7. **Database 32 Resep Makanan Sehat (Lokal & Internasional):**
   - Menu rendah kalori bercita rasa Nusantara: Soto Ayam Bening, Sup Ikan Kakap Kuah Asam, Gado-Gado Sehat, Pepes Ikan Kembung, Pepes Tahu Jamur Kemangi, Bubur Oat Gurih Ayam.
   - Menu diet modern: Salmon Herb Quinoa, Dada Ayam Panggang Lemon, Poke Bowl Tuna, Green Smoothie Bowl, Oatmeal Chia Apel, Zucchini Noodles Bolognese, dll.

8. **Tanpa Integrasi Pembayaran:**
   - Semua fitur gratis dan aktif penuh pada tahap awal ini, dilengkapi banner *NutriPlan Pro Preview* informatif.

---

## 🚀 Cara Menjalankan Aplikasi

Aplikasi dibangun sebagai **Single-Page Application (SPA)** murni tanpa ketergantungan runtime kompilasi yang rumit.

### Opsi 1: Langsung Buka di Browser (Paling Praktis)
1. Buka folder proyek ini di Finder: `/Users/mushab/Documents/Test Antigravity`.
2. Klik ganda pada berkas **`index.html`** untuk membukanya langsung di Google Chrome, Safari, atau Microsoft Edge.

### Opsi 2: Menggunakan Local Web Server Bawaan macOS
Buka aplikasi Terminal, arahkan ke direktori proyek dan jalankan:
```bash
cd "/Users/mushab/Documents/Test Antigravity"
ruby -run -e httpd . -p 8000
```
Lalu buka peramban Anda dan akses URL:
```
http://localhost:8000
```

---

## 📁 Struktur Berkas Proyek

```
Test Antigravity/
├── index.html            # File HTML utama (layout, navigasi, tabs, modals)
├── css/
│   └── styles.css        # Styling kustom, font Plus Jakarta Sans, glassmorphism, @media print
├── js/
│   ├── data.js           # 32 basis data resep lengkap, template plan mingguan & bulanan
│   ├── auth.js           # Autentikasi member, akun demo, registrasi & login via localStorage
│   ├── calculator.js     # Rumus BMR Mifflin-St Jeor, kalkulasi TDEE, BMI, & rasio makro
│   ├── planner.js        # Logika Meal Planner (mingguan/bulanan, swap menu, tracker konsumsi)
│   ├── grocery.js        # Generator daftar belanja otomatis, agregasi bahan, checklist
│   ├── pdf-export.js     # Generator dokumen PDF siap cetak (Meal Plan & Daftar Belanja)
│   └── app.js            # Controller utama, navigasi tab, event bindings, notifikasi toast
└── README.md             # Dokumentasi panduan penggunaan & arsitektur aplikasi
```

---

## 💡 Kredensial Akun Contoh (Demo)
- **Email:** `demo@nutriplan.id`
- **Password:** `password123`
- **Profil:** Sarah Wijaya (Target 1,639 kcal/hari, Defisit Kalori Sehat)
- Tersedia pula tombol **⚡ Masuk Cepat Akun Demo** di modal login tanpa perlu mengetik kata sandi.
