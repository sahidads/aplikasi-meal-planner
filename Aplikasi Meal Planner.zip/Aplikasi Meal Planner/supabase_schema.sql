-- =====================================================================
-- GREEN DIET - SKEMA DATABASE SUPABASE DENGAN ROW LEVEL SECURITY (RLS)
-- =====================================================================
-- Petunjuk:
-- Salin dan jalankan seluruh query SQL ini di:
-- Dashboard Supabase Anda -> SQL Editor -> New Query -> Run
-- =====================================================================

-- 1. TABEL PROFIL MEMBER (profiles)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  full_name TEXT,
  email TEXT,
  avatar_url TEXT,
  age INTEGER DEFAULT 27,
  gender TEXT DEFAULT 'female',
  weight NUMERIC DEFAULT 62,
  height NUMERIC DEFAULT 165,
  activity TEXT DEFAULT 'moderate',
  goal TEXT DEFAULT 'lose',
  bmr NUMERIC DEFAULT 1380,
  tdee NUMERIC DEFAULT 2139,
  target_calories INTEGER DEFAULT 1639,
  macros JSONB DEFAULT '{"carbs": 184, "protein": 123, "fat": 45}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Aktifkan Row Level Security (RLS) untuk profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Kebijakan RLS Profiles: Member hanya bisa membaca dan mengubah datanya sendiri
DROP POLICY IF EXISTS "Member can view own profile" ON public.profiles;
CREATE POLICY "Member can view own profile" 
  ON public.profiles FOR SELECT 
  USING (auth.uid() = id);

DROP POLICY IF EXISTS "Member can insert own profile" ON public.profiles;
CREATE POLICY "Member can insert own profile" 
  ON public.profiles FOR INSERT 
  WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "Member can update own profile" ON public.profiles;
CREATE POLICY "Member can update own profile" 
  ON public.profiles FOR UPDATE 
  USING (auth.uid() = id);

-- Trigger Otomatis: Buat baris profil saat member baru selesai mendaftar di auth.users
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email, avatar_url)
  VALUES (
    new.id,
    COALESCE(new.raw_user_meta_data->>'full_name', 'Member Green Diet'),
    new.email,
    COALESCE(new.raw_user_meta_data->>'avatar_url', 'https://api.dicebear.com/7.x/adventurer/svg?seed=' || new.id)
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();


-- 2. TABEL MEAL PLAN PRIBADI (member_meal_plans)
CREATE TABLE IF NOT EXISTS public.member_meal_plans (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users ON DELETE CASCADE NOT NULL UNIQUE,
  plan_mode TEXT DEFAULT 'weekly',
  weekly_data JSONB,
  monthly_data JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Aktifkan RLS
ALTER TABLE public.member_meal_plans ENABLE ROW LEVEL SECURITY;

-- Kebijakan RLS Member Meal Plans
DROP POLICY IF EXISTS "Member can view own meal plan" ON public.member_meal_plans;
CREATE POLICY "Member can view own meal plan" 
  ON public.member_meal_plans FOR SELECT 
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Member can insert own meal plan" ON public.member_meal_plans;
CREATE POLICY "Member can insert own meal plan" 
  ON public.member_meal_plans FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Member can update own meal plan" ON public.member_meal_plans;
CREATE POLICY "Member can update own meal plan" 
  ON public.member_meal_plans FOR UPDATE 
  USING (auth.uid() = user_id);


-- 3. TABEL DAFTAR BELANJA PRIBADI (member_groceries)
CREATE TABLE IF NOT EXISTS public.member_groceries (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users ON DELETE CASCADE NOT NULL UNIQUE,
  checked_items JSONB DEFAULT '[]'::jsonb,
  custom_items JSONB DEFAULT '[]'::jsonb,
  scope TEXT DEFAULT 'week',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Aktifkan RLS
ALTER TABLE public.member_groceries ENABLE ROW LEVEL SECURITY;

-- Kebijakan RLS Member Groceries
DROP POLICY IF EXISTS "Member can view own groceries" ON public.member_groceries;
CREATE POLICY "Member can view own groceries" 
  ON public.member_groceries FOR SELECT 
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Member can insert own groceries" ON public.member_groceries;
CREATE POLICY "Member can insert own groceries" 
  ON public.member_groceries FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Member can update own groceries" ON public.member_groceries;
CREATE POLICY "Member can update own groceries" 
  ON public.member_groceries FOR UPDATE 
  USING (auth.uid() = user_id);


-- 4. TABEL RESEP PRIBADI / MODIFIKASI MEMBER (member_recipes)
CREATE TABLE IF NOT EXISTS public.member_recipes (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users ON DELETE CASCADE NOT NULL,
  recipe_data JSONB NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Aktifkan RLS
ALTER TABLE public.member_recipes ENABLE ROW LEVEL SECURITY;

-- Kebijakan RLS Member Recipes
DROP POLICY IF EXISTS "Member can view own recipes" ON public.member_recipes;
CREATE POLICY "Member can view own recipes" 
  ON public.member_recipes FOR SELECT 
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Member can insert own recipes" ON public.member_recipes;
CREATE POLICY "Member can insert own recipes" 
  ON public.member_recipes FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Member can update own recipes" ON public.member_recipes;
CREATE POLICY "Member can update own recipes" 
  ON public.member_recipes FOR UPDATE 
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Member can delete own recipes" ON public.member_recipes;
CREATE POLICY "Member can delete own recipes" 
  ON public.member_recipes FOR DELETE 
  USING (auth.uid() = user_id);
