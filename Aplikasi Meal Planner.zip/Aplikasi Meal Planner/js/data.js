/**
 * NutriPlan Green - Basis Data Resep, Menu & Mock Data
 * Berisi 32 resep sehat lengkap dengan nilai gizi, bahan, instruksi, dan tags diet.
 */

const RECIPES_DATA = [
  // ================= SARAPAN (BREAKFAST) =================
  {
    id: "rec_bf_1",
    name: "Oatmeal Apel Kayu Manis & Chia Seeds",
    category: "breakfast",
    calories: 340,
    protein: 12,
    carbs: 58,
    fat: 7,
    cookTime: "10 menit",
    image: "https://images.unsplash.com/photo-1584776296944-ab6fb57b0bdd?auto=format&fit=crop&w=600&q=80",
    tags: ["Tinggi Serat", "Rendah Lemak", "Vegetarian"],
    description: "Bubur havermut hangat dimasak dengan susu almond rendah lemak, taburan apel segar renyah, bubuk kayu manis aromatik, dan biji chia bernutrisi tinggi.",
    ingredients: [
      { name: "Rolled Oats / Havermut", amount: "50", unit: "gram", category: "grains" },
      { name: "Susu Almond Unsweetened", amount: "200", unit: "ml", category: "dairy" },
      { name: "Apel Fuji / Hijau Segar", amount: "1", unit: "buah", category: "produce" },
      { name: "Biji Chia (Chia Seeds)", amount: "1", unit: "sdm", category: "grains" },
      { name: "Bubuk Kayu Manis", amount: "1/2", unit: "sdt", category: "spices" },
      { name: "Madu Alami Murni", amount: "1", unit: "sdt", category: "spices" }
    ],
    instructions: [
      "Masak rolled oats bersama susu almond di atas api sedang selama 5-7 menit hingga mengental.",
      "Potong dadu apel segar.",
      "Tuang oatmeal ke dalam mangkuk, tata potongan apel di atasnya.",
      "Taburkan chia seeds, bubuk kayu manis, dan beri sedikit gerimis madu alami.",
      "Sajikan selagi hangat."
    ]
  },
  {
    id: "rec_bf_2",
    name: "Roti Gandum Panggang Alpukat & Telur Poached",
    category: "breakfast",
    calories: 380,
    protein: 18,
    carbs: 32,
    fat: 20,
    cookTime: "12 menit",
    image: "https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=600&q=80",
    tags: ["Lemak Sehat", "Tinggi Protein", "Kaya Serat"],
    description: "Roti gandum utuh renyah berlapis tumbukan alpukat creamy gurih, dilengkapi telur rebus setengah matang (poached egg) kaya protein.",
    ingredients: [
      { name: "Roti Gandum Utuh (Whole Wheat)", amount: "2", unit: "lembar", category: "grains" },
      { name: "Alpukat Mentega Matang", amount: "1/2", unit: "buah", category: "produce" },
      { name: "Telur Ayam Omega-3", amount: "2", unit: "butir", category: "proteins" },
      { name: "Tomat Ceri", amount: "5", unit: "buah", category: "produce" },
      { name: "Minyak Zaitun (Olive Oil)", amount: "1", unit: "sdt", category: "spices" },
      { name: "Lada Hitam & Garam Laut", amount: "secukupnya", unit: "", category: "spices" }
    ],
    instructions: [
      "Panggang roti gandum hingga kecokelatan dan renyah di kedua sisi.",
      "Lumatkan daging alpukat bersama sejumput garam, lada hitam, dan perasan jeruk nipis.",
      "Rebus air dengan sedikit cuka, buat pusaran air dan masukkan telur perlahan selama 3 menit.",
      "Oleskan alpukat di atas roti panggang, letakkan telur poached, dan hiasi dengan tomat ceri.",
      "Taburkan lada hitam kasar di atasnya."
    ]
  },
  {
    id: "rec_bf_3",
    name: "Green Detox Smoothie Bowl Bayam & Pisang",
    category: "breakfast",
    calories: 310,
    protein: 14,
    carbs: 52,
    fat: 5,
    cookTime: "8 menit",
    image: "https://images.unsplash.com/photo-1590301157890-4810ed352733?auto=format&fit=crop&w=600&q=80",
    tags: ["Detox", "Superfood", "Vegetarian"],
    description: "Smoothie kental kaya antioksidan dari bayam segar muda, pisang beku, yogurt Yunani dengan taburan granola renyah dan biji labu.",
    ingredients: [
      { name: "Bayam Baby Segar", amount: "1", unit: "genggam besar", category: "produce" },
      { name: "Pisang Cavendish Beku", amount: "1", unit: "buah", category: "produce" },
      { name: "Greek Yogurt Plain Rendah Lemak", amount: "100", unit: "gram", category: "dairy" },
      { name: "Granola Rendah Gula", amount: "2", unit: "sdm", category: "grains" },
      { name: "Biji Labu (Pumpkin Seeds)", amount: "1", unit: "sdm", category: "grains" },
      { name: "Air Kelapa Murni", amount: "100", unit: "ml", category: "dairy" }
    ],
    instructions: [
      "Blender bayam segar, pisang beku, greek yogurt, dan air kelapa hingga halus dan kental.",
      "Tuangkan ke dalam mangkuk saji dingin.",
      "Hias bagian atas dengan granola renyah, biji labu, dan irisan pisang tipis.",
      "Nikmati selagi dingin dan segar."
    ]
  },
  {
    id: "rec_bf_4",
    name: "Omelet Putih Telur Sayuran & Jamur Champignon",
    category: "breakfast",
    calories: 290,
    protein: 26,
    carbs: 10,
    fat: 12,
    cookTime: "10 menit",
    image: "https://images.unsplash.com/photo-1510693206972-df098062cb71?auto=format&fit=crop&w=600&q=80",
    tags: ["Sangat Tinggi Protein", "Rendah Karbo", "Keto Friendly"],
    description: "Omelet lembut dari putih telur segar, irisan jamur champignon, paprika merah manis, dan daun bawang wangi.",
    ingredients: [
      { name: "Putih Telur Segar", amount: "4", unit: "butir", category: "proteins" },
      { name: "Telur Utuh", amount: "1", unit: "butir", category: "proteins" },
      { name: "Jamur Kancing / Champignon", amount: "50", unit: "gram", category: "produce" },
      { name: "Paprika Merah", amount: "1/4", unit: "buah", category: "produce" },
      { name: "Bawang Bombay Cincang", amount: "2", unit: "sdm", category: "produce" },
      { name: "Minyak Zaitun untuk wajan", amount: "1", unit: "sdt", category: "spices" }
    ],
    instructions: [
      "Tumis bawang bombay, jamur, dan paprika dengan sedikit minyak zaitun hingga layu wangi.",
      "Kocok putih telur dan telur utuh dengan sejumput garam dan merica putih.",
      "Tuangkan adonan telur merata di atas tumisan sayuran.",
      "Masak dengan api kecil bertutup hingga matang keemasan.",
      "Lipat dua dan sajikan selagi hangat."
    ]
  },
  {
    id: "rec_bf_5",
    name: "Bubur Oat Gurih Ayam Suwir & Telur Setengah Matang",
    category: "breakfast",
    calories: 320,
    protein: 24,
    carbs: 38,
    fat: 9,
    cookTime: "12 menit",
    image: "https://images.unsplash.com/photo-1541544741938-0af808871cc0?auto=format&fit=crop&w=600&q=80",
    tags: ["Kearifan Lokal", "Tinggi Protein", "Hangat"],
    description: "Bubur ayam versi rendah kalori berbahan dasar havermut gurih kaldu ayam asli, dilengkapi suwiran dada ayam empuk, telur rebus, dan daun seledri.",
    ingredients: [
      { name: "Quick Cooking Oats", amount: "45", unit: "gram", category: "grains" },
      { name: "Dada Ayam Suwir Rebus", amount: "80", unit: "gram", category: "proteins" },
      { name: "Telur Ayam Rebus 1/2 Matang", amount: "1", unit: "butir", category: "proteins" },
      { name: "Kaldu Ayam Kampung Bening", amount: "250", unit: "ml", category: "spices" },
      { name: "Daun Seledri & Bawang Goreng", amount: "secukupnya", unit: "", category: "produce" },
      { name: "Kecap Asin Rendah Natrium", amount: "1", unit: "sdt", category: "spices" }
    ],
    instructions: [
      "Didihkan kaldu ayam bening dalam panci kecil.",
      "Masukkan havermut dan sedikit lada putih, aduk hingga teksturnya lembut mengental.",
      "Tuang ke mangkuk, beri topping dada ayam suwir, telur rebus belah dua, daun seledri, dan bawang goreng.",
      "Beri tetesan kecap asin rendah garam sebelum disantap hangat."
    ]
  },
  {
    id: "rec_bf_6",
    name: "Pancake Gandum Pisang Tanpa Tepung Terigu",
    category: "breakfast",
    calories: 330,
    protein: 15,
    carbs: 48,
    fat: 8,
    cookTime: "15 menit",
    image: "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?auto=format&fit=crop&w=600&q=80",
    tags: ["Gluten-Free", "Tinggi Serat", "Favorit Keluarga"],
    description: "Pancake sehat dibuat murni dari gandum giling, pisang ambon manis matang alami, dan telur ayam kampung tanpa tambahan gula pasir.",
    ingredients: [
      { name: "Tepung Oat Gandum Halus", amount: "50", unit: "gram", category: "grains" },
      { name: "Pisang Ambon Matang Halus", amount: "1", unit: "buah", category: "produce" },
      { name: "Telur Ayam Kampung", amount: "2", unit: "butir", category: "proteins" },
      { name: "Susu Kedelai Tanpa Gula", amount: "50", unit: "ml", category: "dairy" },
      { name: "Baking Powder & Kayu Manis", amount: "1/2", unit: "sdt", category: "spices" }
    ],
    instructions: [
      "Campur tepung oat, pisang lumat, telur, susu kedelai, dan baking powder hingga adonan kental merata.",
      "Panaskan wajan teflon tanpa minyak di atas api kecil.",
      "Tuang 2 sendok sayur adonan, balik setelah berbusa kecil di permukaan (sekitar 2 menit per sisi).",
      "Sajikan tumpuk hangat dengan potongan buah segar."
    ]
  },
  {
    id: "rec_bf_7",
    name: "Tortilla Wrap Telur Orak-Arik & Bayam Segar",
    category: "breakfast",
    calories: 350,
    protein: 21,
    carbs: 32,
    fat: 14,
    cookTime: "10 menit",
    image: "https://images.unsplash.com/photo-1626700051175-6818013e1d4f?auto=format&fit=crop&w=600&q=80",
    tags: ["Praktis Dibawa", "Tinggi Protein", "Rendah Kalori"],
    description: "Tortilla gandum utuh membungkus telur orak-arik lembut, daun bayam baby renyah, dan keju parmesan gurih.",
    ingredients: [
      { name: "Kulit Tortilla Gandum Utuh", amount: "1", unit: "lembar", category: "grains" },
      { name: "Telur Ayam Segar", amount: "2", unit: "butir", category: "proteins" },
      { name: "Bayam Baby Segar", amount: "1", unit: "genggam", category: "produce" },
      { name: "Tomat Merah Cincang", amount: "1/2", unit: "buah", category: "produce" },
      { name: "Minyak Zaitun", amount: "1/2", unit: "sdt", category: "spices" }
    ],
    instructions: [
      "Kocok telur bersama sedikit garam dan lada, buat scrambled egg lembut di teflon.",
      "Hangatkan kulit tortilla di teflon selama 30 detik.",
      "Susun daun bayam segar, tomat cincang, dan telur orak-arik di tengah tortilla.",
      "Gulung padat dan potong diagonal. Siap dinikmati atau dibawa bekal kerja."
    ]
  },
  {
    id: "rec_bf_8",
    name: "Roti Gandum Selai Kacang Alami & Biji Wijen",
    category: "breakfast",
    calories: 310,
    protein: 13,
    carbs: 36,
    fat: 14,
    cookTime: "5 menit",
    image: "https://images.unsplash.com/photo-1509722747041-616f39b57569?auto=format&fit=crop&w=600&q=80",
    tags: ["Cepat 5 Menit", "Energi Tahan Lama", "Vegetarian"],
    description: "Dua lembar roti gandum panggang diolesi selai kacang tanah murni tanpa gula tambahan, taburan biji chia dan irisan stroberi segar.",
    ingredients: [
      { name: "Roti Gandum Utuh", amount: "2", unit: "lembar", category: "grains" },
      { name: "Selai Kacang Murni No Sugar Added", amount: "1.5", unit: "sdm", category: "grains" },
      { name: "Buah Stroberi Iris", amount: "4", unit: "buah", category: "produce" },
      { name: "Biji Chia", amount: "1/2", unit: "sdm", category: "grains" }
    ],
    instructions: [
      "Panggang roti gandum hingga renyah.",
      "Oleskan selai kacang alami secara merata.",
      "Tata irisan buah stroberi dan taburkan biji chia di atasnya."
    ]
  },

  // ================= MAKAN SIANG (LUNCH) =================
  {
    id: "rec_lu_1",
    name: "Nasi Merah Dada Ayam Bakar Madu Lemon & Brokoli",
    category: "lunch",
    calories: 460,
    protein: 42,
    carbs: 48,
    fat: 10,
    cookTime: "25 menit",
    image: "https://images.unsplash.com/photo-1532550907401-a500c9a57435?auto=format&fit=crop&w=600&q=80",
    tags: ["Tinggi Protein", "Diet Seimbang", "Favorit Atlet"],
    description: "Menu diet andalan pembakar lemak: Dada ayam tanpa kulit dipanggang dengan marinasi lemon, jahe, bawang putih, disajikan bersama nasi merah pulen dan brokoli kukus segar.",
    ingredients: [
      { name: "Dada Ayam Fillet Tanpa Kulit", amount: "180", unit: "gram", category: "proteins" },
      { name: "Beras Merah Organik Matang", amount: "100", unit: "gram", category: "grains" },
      { name: "Brokoli Segar", amount: "100", unit: "gram", category: "produce" },
      { name: "Jeruk Lemon Segar", amount: "1/2", unit: "buah", category: "produce" },
      { name: "Bawang Putih Halus", amount: "2", unit: "siung", category: "spices" },
      { name: "Madu Alami Murni", amount: "1", unit: "sdt", category: "spices" },
      { name: "Kecap Asin Rendah Garam (Tamari/Shoyu)", amount: "1", unit: "sdm", category: "spices" }
    ],
    instructions: [
      "Marinasi dada ayam dengan perasan air lemon, bawang putih halus, kecap asin rendah garam, dan madu selama 15 menit.",
      "Panggang dada ayam di atas wajan anti lengket atau panggangan selama 6-8 menit tiap sisi hingga matang juicy.",
      "Kukus brokoli selama 3-4 menit agar warnanya tetap hijau segar dan renyah.",
      "Tata nasi merah hangat, dada ayam bakar yang diiris melintang, dan brokoli kukus di piring saji."
    ]
  },
  {
    id: "rec_lu_2",
    name: "Gado-Gado Siram Sehat dengan Telur Rebus & Tahu Tempe",
    category: "lunch",
    calories: 420,
    protein: 24,
    carbs: 42,
    fat: 16,
    cookTime: "20 menit",
    image: "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80",
    tags: ["Kearifan Lokal", "Tinggi Serat", "Vegetarian"],
    description: "Kelezatan tradisional Indonesia versi diet: Sayuran rebus segar berlimpah, tempe dan tahu panggang tanpa minyak, telur rebus, disiram saus kacang rendah kalori berbahan dasar almond/kacang sangrai.",
    ingredients: [
      { name: "Tempe Kedelai Segar (Panggang)", amount: "75", unit: "gram", category: "proteins" },
      { name: "Tahu Putih Segar (Panggang)", amount: "75", unit: "gram", category: "proteins" },
      { name: "Telur Ayam Rebus", amount: "1", unit: "butir", category: "proteins" },
      { name: "Kangkung / Bayam Rebus", amount: "50", unit: "gram", category: "produce" },
      { name: "Tauge Rebus", amount: "50", unit: "gram", category: "produce" },
      { name: "Kacang Panjang Rebus", amount: "4", unit: "lonjor", category: "produce" },
      { name: "Bumbu Kacang Sangrai Halus (Rendah Minyak)", amount: "3", unit: "sdm", category: "spices" }
    ],
    instructions: [
      "Panggang irisan tempe dan tahu menggunakan air-fryer atau teflon anti lengket tanpa minyak hingga matang renyah.",
      "Rebus sayuran (kangkung, kacang panjang, tauge) sebentar saja dalam air mendidih lalu tiriskan.",
      "Larutkan bumbu kacang sangrai dengan sedikit air hangat hingga tingkat kekentalan pas.",
      "Susun sayuran, tahu, tempe, dan telur rebus iris di atas piring, lalu siramkan saus kacang gurih di atasnya."
    ]
  },
  {
    id: "rec_lu_3",
    name: "Salmon Panggang Herb & Quinoa Salad Alpukat",
    category: "lunch",
    calories: 490,
    protein: 38,
    carbs: 35,
    fat: 22,
    cookTime: "20 menit",
    image: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&w=600&q=80",
    tags: ["Omega-3 Tinggi", "Superfood", "Jantung Sehat"],
    description: "Fillet salmon liar kaya asam lemak Omega-3 dipanggang dengan rosemary dan dill, dipadukan bersama salad quinoa bernutrisi tinggi dan potongan alpukat segar.",
    ingredients: [
      { name: "Fillet Salmon Segar", amount: "150", unit: "gram", category: "proteins" },
      { name: "Biji Quinoa Masak", amount: "80", unit: "gram", category: "grains" },
      { name: "Alpukat Mentega Segar", amount: "1/2", unit: "buah", category: "produce" },
      { name: "Timun Jepang (Kyuri)", amount: "1/2", unit: "buah", category: "produce" },
      { name: "Rosemary & Lada Hitam", amount: "secukupnya", unit: "", category: "spices" },
      { name: "Minyak Zaitun Ekstra Virgin", amount: "1", unit: "sdt", category: "spices" }
    ],
    instructions: [
      "Taburi fillet salmon dengan rosemary kering, garam laut, lada hitam, dan perasan jeruk lemon.",
      "Panggang salmon di wajan panas selama 3-4 menit di sisi kulit hingga renyah, lalu balik dan masak 2 menit lagi hingga lembut.",
      "Campur quinoa matang dengan potongan mentimun jepang, alpukat dadu, dan 1 sdt minyak zaitun.",
      "Sajikan salmon bersama salad quinoa yang segar."
    ]
  },
  {
    id: "rec_lu_4",
    name: "Tumis Daging Sapi Lada Hitam Rendah Lemak & Beras Merah",
    category: "lunch",
    calories: 450,
    protein: 36,
    carbs: 45,
    fat: 14,
    cookTime: "20 menit",
    image: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80",
    tags: ["Zat Besi Tinggi", "Tinggi Protein", "Rendah Lemak"],
    description: "Daging sapi bagian tenderloin rendah lemak ditumis cepat dengan saus lada hitam harum, paprika triwarna, dan disajikan dengan nasi merah.",
    ingredients: [
      { name: "Daging Sapi Has Dalam (Tenderloin)", amount: "130", unit: "gram", category: "proteins" },
      { name: "Beras Merah Matang", amount: "100", unit: "gram", category: "grains" },
      { name: "Paprika Merah & Hijau", amount: "1/2", unit: "buah", category: "produce" },
      { name: "Bawang Bombay", amount: "1/2", unit: "buah", category: "produce" },
      { name: "Lada Hitam Kasar", amount: "1", unit: "sdm", category: "spices" },
      { name: "Saus Tiram Rendah Natrium", amount: "1", unit: "sdm", category: "spices" }
    ],
    instructions: [
      "Iris tipis daging sapi has dalam searah serat daging.",
      "Tumis bawang bombay dan lada hitam hingga wangi semerbak.",
      "Masukkan irisan daging, masak cepat dengan api besar selama 3-4 menit.",
      "Tambahkan saus tiram rendah garam dan irisan paprika, aduk sebentar hingga layu renyah.",
      "Angkat dan sajikan bersama seporsi nasi merah hangat."
    ]
  },
  {
    id: "rec_lu_5",
    name: "Soto Ayam Bening Kuah Kunyit & Bihun Jagung",
    category: "lunch",
    calories: 390,
    protein: 32,
    carbs: 42,
    fat: 9,
    cookTime: "25 menit",
    image: "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=600&q=80",
    tags: ["Segar Berkuah", "Anti-Inflamasi", "Rendah Lemak"],
    description: "Soto ayam khas nusantara kuah bening rempah kunyit jahe, dengan suwiran dada ayam empuk, bihun jagung rendah GI, tauge renyah, dan perasan jeruk nipis.",
    ingredients: [
      { name: "Dada Ayam Fillet Tanpa Kulit", amount: "150", unit: "gram", category: "proteins" },
      { name: "Bihun Jagung Rendah Glikemik Matang", amount: "60", unit: "gram", category: "grains" },
      { name: "Tauge Segar Seduh", amount: "50", unit: "gram", category: "produce" },
      { name: "Kunyit, Jahe, Serai Dimemarkan", amount: "2", unit: "batang", category: "spices" },
      { name: "Jeruk Nipis Segar", amount: "1", unit: "buah", category: "produce" },
      { name: "Telur Ayam Rebus", amount: "1/2", unit: "butir", category: "proteins" }
    ],
    instructions: [
      "Rebus dada ayam dalam 500 ml air dengan kunyit, jahe, bawang putih halus, daun jeruk, dan serai hingga harum.",
      "Angkat ayam lalu suwir-suwir.",
      "Tata bihun jagung dan tauge dalam mangkuk saji, letakkan suwiran ayam dan telur rebus di atasnya.",
      "Siramkan kuah kuning soto panas mendidih dan beri perasan jeruk nipis segar."
    ]
  },
  {
    id: "rec_lu_6",
    name: "Poke Bowl Tuna Segar Edamame & Nasi Shirataki",
    category: "lunch",
    calories: 420,
    protein: 38,
    carbs: 30,
    fat: 14,
    cookTime: "15 menit",
    image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80",
    tags: ["Omega-3", "Segar Alami", "Tinggi Protein"],
    description: "Potongan ikan tuna segar dadu dimarinasi saus kecap asin wijen, disajikan di atas nasi shirataki dingin bersama edamame, rumput laut nori, dan irisan kyuri.",
    ingredients: [
      { name: "Fillet Ikan Tuna Segar Sashimi-grade", amount: "150", unit: "gram", category: "proteins" },
      { name: "Nasi Shirataki Dingin", amount: "120", unit: "gram", category: "grains" },
      { name: "Kacang Edamame Kupas Rebus", amount: "40", unit: "gram", category: "produce" },
      { name: "Timun Jepang (Kyuri) Iris", amount: "1/2", unit: "buah", category: "produce" },
      { name: "Minyak Wijen & Kecap Asin Rendah Garam", amount: "1", unit: "sdm", category: "spices" },
      { name: "Rumput Laut Nori Panggang", amount: "1", unit: "lembar", category: "produce" }
    ],
    instructions: [
      "Potong tuna segar bentuk dadu 1.5 cm, lumuri dengan minyak wijen, kecap asin, dan sejumput wijen sangrai selama 5 menit.",
      "Siapkan mangkuk berisi nasi shirataki yang sudah didinginkan.",
      "Susun tuna marinasi, edamame, irisan timun, dan potongan nori di atas nasi.",
      "Nikmati langsung dalam keadaan segar."
    ]
  },
  {
    id: "rec_lu_7",
    name: "Pepes Ikan Kembung Bumbu Kuning & Sayur Asem",
    category: "lunch",
    calories: 380,
    protein: 34,
    carbs: 32,
    fat: 10,
    cookTime: "30 menit",
    image: "https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=600&q=80",
    tags: ["Lokal Juara", "Tinggi Kalsium", "Bebas Minyak"],
    description: "Ikan kembung kaya Omega-3 dan kalsium dibumbui kunyit, daun kemangi, dan cabai merah, dibungkus daun pisang kukus wangi, dipadukan semangkuk sayur asem segar.",
    ingredients: [
      { name: "Ikan Kembung Segar Bersih", amount: "2", unit: "ekor", category: "proteins" },
      { name: "Beras Merah Matang", amount: "80", unit: "gram", category: "grains" },
      { name: "Sayur Asem (Labu Siam, Kacang Panjang, Jagung)", amount: "1", unit: "mangkuk", category: "produce" },
      { name: "Bumbu Kuning Halus & Kemangi", amount: "2", unit: "sdm", category: "spices" },
      { name: "Daun Pisang Pembungkus", amount: "2", unit: "lembar", category: "produce" }
    ],
    instructions: [
      "Lumuri ikan kembung dengan bumbu kuning halus dan daun kemangi segar.",
      "Bungkus rapat dengan daun pisang, semat kedua ujungnya.",
      "Kukus selama 20 menit hingga ikan matang sempurna dan bumbu meresap ke dalam daging.",
      "Panggang sebentar di teflon kering 3 menit agar aroma daun pisang keluar semerbak.",
      "Sajikan bersama nasi merah dan sayur asem segar."
    ]
  },
  {
    id: "rec_lu_8",
    name: "Nasi Merah Tumis Jamur Tiram & Dada Ayam Cincang",
    category: "lunch",
    calories: 410,
    protein: 35,
    carbs: 46,
    fat: 8,
    cookTime: "18 menit",
    image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80",
    tags: ["Rendah Kalori", "Tinggi Serat", "Cepat Matang"],
    description: "Kombinasi serat jamur tiram kenyal berpadu dengan gurihnya cincangan dada ayam berbumbu bawang putih jahe, disajikan bersama nasi merah.",
    ingredients: [
      { name: "Dada Ayam Cincang Tanpa Lemak", amount: "130", unit: "gram", category: "proteins" },
      { name: "Jamur Tiram Disuwir", amount: "100", unit: "gram", category: "produce" },
      { name: "Beras Merah Matang", amount: "100", unit: "gram", category: "grains" },
      { name: "Kecap Manis Rendah Kalori (Stevia)", amount: "1", unit: "sdm", category: "spices" },
      { name: "Minyak Zaitun untuk menumis", amount: "1", unit: "sdt", category: "spices" }
    ],
    instructions: [
      "Tumis bawang putih cincang dan cabai rawit dengan 1 sdt minyak zaitun.",
      "Masukkan dada ayam cincang, masak hingga berubah warna putih matang.",
      "Tambahkan suwiran jamur tiram dan sedikit air, beri kecap manis rendah kalori dan garam secukupnya.",
      "Masak hingga kuah mengental dan bumbu meresap.",
      "Sajikan di atas sepiring nasi merah hangat."
    ]
  },

  // ================= MAKAN MALAM (DINNER) =================
  {
    id: "rec_dn_1",
    name: "Sup Ikan Kakap Bening Kuah Asam Kemangi",
    category: "dinner",
    calories: 280,
    protein: 34,
    carbs: 12,
    fat: 6,
    cookTime: "25 menit",
    image: "https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=600&q=80",
    tags: ["Rendah Kalori", "Tinggi Protein", "Hangat & Segar"],
    description: "Sup hangat berkuah bening aromatik khas Nusantara dengan potongan ikan kakap segar, belimbing wuluh asam segar, tomat merah, dan daun kemangi wangi.",
    ingredients: [
      { name: "Fillet Ikan Kakap Merah Segar", amount: "200", unit: "gram", category: "proteins" },
      { name: "Daun Kemangi Segar", amount: "1", unit: "ikat", category: "produce" },
      { name: "Belimbing Wuluh / Tomat Hijau", amount: "3", unit: "buah", category: "produce" },
      { name: "Tomat Merah Segar", amount: "1", unit: "buah", category: "produce" },
      { name: "Serai Dimemarkan", amount: "2", unit: "batang", category: "spices" },
      { name: "Daun Jeruk Segar", amount: "3", unit: "lembar", category: "spices" },
      { name: "Jahe Dimemarkan", amount: "2", unit: "cm", category: "spices" }
    ],
    instructions: [
      "Didihkan 500 ml air bersama serai, daun jeruk, jahe, dan irisan bawang putih.",
      "Masukkan potongan ikan kakap merah dan belimbing sayur, masak selama 5 menit hingga ikan matang lembut.",
      "Tambahkan garam laut, sedikit lada putih, dan irisan tomat merah.",
      "Sesaat sebelum diangkat, masukkan daun kemangi segar agar aromanya mekar sempurna.",
      "Sajikan hangat untuk makan malam yang menenangkan perut."
    ]
  },
  {
    id: "rec_dn_2",
    name: "Pepes Tahu Jamur Tiram Kemangi & Nasi Shirataki",
    category: "dinner",
    calories: 230,
    protein: 16,
    carbs: 18,
    fat: 8,
    cookTime: "30 menit",
    image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80",
    tags: ["Sangat Rendah Kalori", "Vegetarian", "Detoks Malam"],
    description: "Menu makan malam ramah defisit kalori: Tahu sutra berpadu jamur tiram lezat dibumbui rempah kunyit daun kemangi, dikukus dalam balutan daun pisang wangi.",
    ingredients: [
      { name: "Tahu Sutra / Tahu Putih Halus", amount: "150", unit: "gram", category: "proteins" },
      { name: "Jamur Tiram Disuwir", amount: "80", unit: "gram", category: "produce" },
      { name: "Nasi Shirataki / Konjac Rice", amount: "100", unit: "gram", category: "grains" },
      { name: "Daun Kemangi Segar", amount: "1", unit: "genggam", category: "produce" },
      { name: "Bawang Merah & Putih Halus", amount: "4", unit: "siung", category: "spices" },
      { name: "Kunyit & Cabai Merah Halus", amount: "1", unit: "sdm", category: "spices" },
      { name: "Daun Pisang Pembungkus", amount: "2", unit: "lembar", category: "produce" }
    ],
    instructions: [
      "Hancurkan tahu hingga halus lalu campurkan dengan suwiran jamur tiram dan bumbu halus.",
      "Tambahkan daun kemangi, sebutir putih telur (opsional), dan garam secukupnya.",
      "Bungkus adonan dalam daun pisang, semat ujungnya dengan tusuk gigi.",
      "Kukus selama 20 menit, lalu panggang sebentar di teflon kering agar aroma daun pisang semakin keluar.",
      "Sajikan dengan nasi shirataki hangat yang bebas kalori jahat."
    ]
  },
  {
    id: "rec_dn_3",
    name: "Salad Dada Ayam Mediterania & Saus Lemon Herb",
    category: "dinner",
    calories: 320,
    protein: 36,
    carbs: 14,
    fat: 12,
    cookTime: "15 menit",
    image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=600&q=80",
    tags: ["Rendah Karbohidrat", "Tinggi Protein", "Keto Friendly"],
    description: "Salad segar warna-warni daun selada romaine, mentimun renyah, zaitun hitam, tomat ceri, dan suwiran dada ayam panggang dengan dressing minyak zaitun lemon.",
    ingredients: [
      { name: "Dada Ayam Panggang Suwir", amount: "150", unit: "gram", category: "proteins" },
      { name: "Selada Romaine Segar", amount: "100", unit: "gram", category: "produce" },
      { name: "Tomat Ceri", amount: "6", unit: "buah", category: "produce" },
      { name: "Mentimun Jepang Iris", amount: "1/2", unit: "buah", category: "produce" },
      { name: "Minyak Zaitun Ekstra Virgin", amount: "1", unit: "sdm", category: "spices" },
      { name: "Perasan Lemon & Oregano Kering", amount: "1", unit: "sdm", category: "spices" }
    ],
    instructions: [
      "Cuci bersih daun selada romaine dengan air dingin es agar tetap renyah, sobek-sobek kasar.",
      "Susun selada, tomat ceri belah dua, dan irisan mentimun dalam mangkuk salad besar.",
      "Letakkan suwiran dada ayam hangat di atasnya.",
      "Kocok minyak zaitun, air lemon, oregano, dan sejumput garam sebagai dressing, lalu siramkan merata.",
      "Aduk perlahan sebelum dinikmati."
    ]
  },
  {
    id: "rec_dn_4",
    name: "Tumis Udang Buncis Jagung Manis & Kentang Kukus",
    category: "dinner",
    calories: 340,
    protein: 30,
    carbs: 38,
    fat: 8,
    cookTime: "18 menit",
    image: "https://images.unsplash.com/photo-1555126634-323283e090fa?auto=format&fit=crop&w=600&q=80",
    tags: ["Tinggi Protein", "Rendah Lemak", "Cepat Disajikan"],
    description: "Udang laut segar ditumis renyah bersama buncis muda dan pipilan jagung manis, disajikan berdampingan dengan kentang kukus kulit sebagai sumber karbohidrat kompleks.",
    ingredients: [
      { name: "Udang Segar Kupas", amount: "150", unit: "gram", category: "proteins" },
      { name: "Buncis Muda Segar", amount: "80", unit: "gram", category: "produce" },
      { name: "Jagung Manis Pipil", amount: "40", unit: "gram", category: "produce" },
      { name: "Kentang Sedang Kukus", amount: "1", unit: "buah", category: "produce" },
      { name: "Bawang Putih Cincang", amount: "2", unit: "siung", category: "spices" },
      { name: "Minyak Wijen & Garam", amount: "1/2", unit: "sdt", category: "spices" }
    ],
    instructions: [
      "Kukus kentang hingga empuk, potong empat bagian.",
      "Tumis bawang putih dengan sedikit minyak hingga keemasan.",
      "Masukkan udang kupas, aduk hingga berubah warna kemerahan (sekitar 2-3 menit).",
      "Tambahkan buncis muda dan jagung manis pipil, beri tetesan minyak wijen dan sedikit garam.",
      "Masak 2 menit lagi agar sayuran tetap renyah dan sajikan bersama kentang kukus."
    ]
  },
  {
    id: "rec_dn_5",
    name: "Capcay Seafood Kuah Bening Rendah Natrium",
    category: "dinner",
    calories: 270,
    protein: 28,
    carbs: 22,
    fat: 6,
    cookTime: "20 menit",
    image: "https://images.unsplash.com/photo-1541832676-9b763b0239ab?auto=format&fit=crop&w=600&q=80",
    tags: ["Kaya Vitamin", "Serat Tinggi", "Rendah Kalori"],
    description: "Aneka ragam sayuran segar (kembang kol, wortel, sawi hijau, jamur) dimasak cepat bersama udang dan cumi segar dengan kuah kaldu bawang putih gurih tanpa MSG.",
    ingredients: [
      { name: "Udang & Cumi Segar Kupas", amount: "120", unit: "gram", category: "proteins" },
      { name: "Kembang Kol & Wortel Iris", amount: "100", unit: "gram", category: "produce" },
      { name: "Sawi Hijau / Pokcoy", amount: "60", unit: "gram", category: "produce" },
      { name: "Bawang Putih Geprek", amount: "3", unit: "siung", category: "spices" },
      { name: "Minyak Wijen", amount: "1/2", unit: "sdt", category: "spices" }
    ],
    instructions: [
      "Tumis bawang putih geprek hingga harum kekuningan.",
      "Masukkan udang dan cumi, tumis hingga setengah matang.",
      "Tambahkan wortel dan kembang kol bersama 200 ml air atau kaldu sayur bening.",
      "Setelah mendidih, masukkan sawi hijau, garam, dan minyak wijen sebentar saja.",
      "Angkat dan santap hangat selagi sayuran masih renyah."
    ]
  },
  {
    id: "rec_dn_6",
    name: "Zucchini Noodle Saus Bolognese Daging Rendah Lemak",
    category: "dinner",
    calories: 295,
    protein: 30,
    carbs: 16,
    fat: 11,
    cookTime: "20 menit",
    image: "https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&w=600&q=80",
    tags: ["Ultra Low Carb", "Keto Friendly", "Pasta Sehat"],
    description: "Mi dari serutan sayuran labu jepang (zucchini) bebas gluten, disiram saus tomat bolognese murni berisikan daging sapi cincang tanpa lemak.",
    ingredients: [
      { name: "Zucchini Segar (Diserut Bentuk Mi/Zoodles)", amount: "200", unit: "gram", category: "produce" },
      { name: "Daging Sapi Cincang Rendah Lemak (95% Lean)", amount: "120", unit: "gram", category: "proteins" },
      { name: "Puree Tomat Alami Murni (No Sugar)", amount: "100", unit: "gram", category: "produce" },
      { name: "Bawang Bombay & Oregano Kering", amount: "1", unit: "sdm", category: "spices" },
      { name: "Minyak Zaitun", amount: "1", unit: "sdt", category: "spices" }
    ],
    instructions: [
      "Serut zucchini memanjang menyerupai mi spageti, sangrai cepat di teflon kering 1-2 menit agar tidak berair.",
      "Tumis bawang bombay dengan minyak zaitun, masukkan daging sapi cincang hingga matang kecokelatan.",
      "Tuangkan puree tomat murni, taburi oregano dan garam, masak hingga saus bolognese mengental wangi.",
      "Tata mi zucchini di piring, siram saus bolognese di atasnya."
    ]
  },
  {
    id: "rec_dn_7",
    name: "Sup Tahu Sutra Kimchi & Jamur Enoki Hangat",
    category: "dinner",
    calories: 210,
    protein: 15,
    carbs: 18,
    fat: 6,
    cookTime: "15 menit",
    image: "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?auto=format&fit=crop&w=600&q=80",
    tags: ["Probiotik Alami", "Sangat Rendah Kalori", "Hangat"],
    description: "Sup hangat kaya probiotik dari fermentasi kimchi asli, potongan tahu sutra lembut, jamur enoki, dan daun bawang segar.",
    ingredients: [
      { name: "Tahu Sutra Potong Dadu", amount: "150", unit: "gram", category: "proteins" },
      { name: "Kimchi Fermentasi Segar", amount: "80", unit: "gram", category: "produce" },
      { name: "Jamur Enoki Bersih", amount: "50", unit: "gram", category: "produce" },
      { name: "Daun Bawang Iris", amount: "1", unit: "batang", category: "produce" },
      { name: "Minyak Wijen & Bawang Putih", amount: "1/2", unit: "sdt", category: "spices" }
    ],
    instructions: [
      "Tumis kimchi sebentar dengan beberapa tetes minyak wijen.",
      "Tambahkan 400 ml air kaldu sayur, didihkan.",
      "Masukkan potongan tahu sutra dan jamur enoki, masak selama 4 menit.",
      "Taburkan irisan daun bawang di atasnya dan sajikan selagi panas mendidih."
    ]
  },
  {
    id: "rec_dn_8",
    name: "Dada Ayam Panggang Rosemary & Ubi Jalar Manis Kukus",
    category: "dinner",
    calories: 350,
    protein: 36,
    carbs: 36,
    fat: 6,
    cookTime: "25 menit",
    image: "https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?auto=format&fit=crop&w=600&q=80",
    tags: ["Karbo Kompleks", "Tinggi Protein", "Mengenyangkan"],
    description: "Fillet dada ayam dibalut rempah rosemary dan lada hitam panggang, disajikan dengan manis alaminya ubi jalar kukus.",
    ingredients: [
      { name: "Dada Ayam Fillet", amount: "150", unit: "gram", category: "proteins" },
      { name: "Ubi Jalar Oranye Kukus", amount: "120", unit: "gram", category: "produce" },
      { name: "Buncis Muda Kukus", amount: "60", unit: "gram", category: "produce" },
      { name: "Rosemary & Lada Hitam", amount: "secukupnya", unit: "", category: "spices" },
      { name: "Minyak Zaitun Oles", amount: "1/2", unit: "sdt", category: "spices" }
    ],
    instructions: [
      "Kukus ubi jalar hingga empuk manis.",
      "Olesi dada ayam dengan sedikit minyak zaitun, taburi rosemary dan lada hitam.",
      "Panggang di teflon panas 6 menit per sisi sampai matang juicy.",
      "Sajikan bersama irisan ubi kukus dan buncis manis."
    ]
  },

  // ================= CAMILAN SEHAT (SNACKS) =================
  {
    id: "rec_sn_1",
    name: "Greek Yogurt dengan Madu & Beri Segar",
    category: "snack",
    calories: 160,
    protein: 12,
    carbs: 20,
    fat: 3,
    cookTime: "3 menit",
    image: "https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=600&q=80",
    tags: ["Probiotik", "Tinggi Protein", "Rendah Kalori"],
    description: "Greek yogurt padat protein berpadu dengan stroberi/blueberry segar kaya antioksidan dan sentuhan manis alami madu murni.",
    ingredients: [
      { name: "Greek Yogurt Plain Rendah Lemak", amount: "120", unit: "gram", category: "dairy" },
      { name: "Buah Stroberi / Blueberry Segar", amount: "50", unit: "gram", category: "produce" },
      { name: "Madu Alami Murni", amount: "1", unit: "sdt", category: "spices" }
    ],
    instructions: [
      "Tuang greek yogurt ke dalam gelas saji.",
      "Beri topping buah beri segar dan siraman madu murni.",
      "Sajikan langsung dalam keadaan dingin."
    ]
  },
  {
    id: "rec_sn_2",
    name: "Kacang Almond Panggang & Apel Iris Kayu Manis",
    category: "snack",
    calories: 180,
    protein: 6,
    carbs: 22,
    fat: 10,
    cookTime: "5 menit",
    image: "https://images.unsplash.com/photo-1508746829417-e6f548d8d6ed?auto=format&fit=crop&w=600&q=80",
    tags: ["Lemak Baik", "Mengenyangkan", "Bebas Masak"],
    description: "Camilan praktis pencegah lapar sore hari: Apel renyah ditaburi bubuk kayu manis dipasangkan dengan kacang almond panggang tanpa garam.",
    ingredients: [
      { name: "Kacang Almond Panggang Tanpa Garam", amount: "20", unit: "gram", category: "grains" },
      { name: "Apel Hijau Segar", amount: "1", unit: "buah", category: "produce" },
      { name: "Bubuk Kayu Manis", amount: "sejumput", unit: "", category: "spices" }
    ],
    instructions: [
      "Potong apel menjadi irisan tipis.",
      "Taburkan bubuk kayu manis di atas irisan apel.",
      "Nikmati bersama butiran kacang almond gurih renyah."
    ]
  },
  {
    id: "rec_sn_3",
    name: "Edamame Rebus Garam Laut",
    category: "snack",
    calories: 140,
    protein: 11,
    carbs: 10,
    fat: 5,
    cookTime: "6 menit",
    image: "https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&w=600&q=80",
    tags: ["Nabati", "Tinggi Serat", "Kaya Protein"],
    description: "Kacang kedelai muda jepang (edamame) rebus hangat yang kaya isoflavon dan protein nabati, ditaburi sedikit garam laut alami.",
    ingredients: [
      { name: "Kacang Edamame Segar Berkulit", amount: "150", unit: "gram", category: "produce" },
      { name: "Garam Laut Alami (Sea Salt)", amount: "1/2", unit: "sdt", category: "spices" }
    ],
    instructions: [
      "Didihkan air dalam panci dengan sedikit garam.",
      "Masukkan edamame segar, rebus selama 5 menit hingga kacang matang lembut.",
      "Tiriskan dan taburi sedikit sea salt saat disajikan."
    ]
  },
  {
    id: "rec_sn_4",
    name: "Puding Chia Susu Kedelai & Mangga Segar",
    category: "snack",
    calories: 170,
    protein: 7,
    carbs: 24,
    fat: 6,
    cookTime: "5 menit (+dingin)",
    image: "https://images.unsplash.com/photo-1543339308-43e59d6b73a6?auto=format&fit=crop&w=600&q=80",
    tags: ["Tinggi Serat", "Vegan", "Menyegarkan"],
    description: "Puding sehat berbahan dasar biji chia yang direndam dalam susu kedelai tanpa gula, disajikan dengan pure mangga harum manis.",
    ingredients: [
      { name: "Biji Chia (Chia Seeds)", amount: "2", unit: "sdm", category: "grains" },
      { name: "Susu Kedelai Tanpa Gula", amount: "120", unit: "ml", category: "dairy" },
      { name: "Mangga Harum Manis Dadu", amount: "50", unit: "gram", category: "produce" }
    ],
    instructions: [
      "Campurkan biji chia ke dalam susu kedelai, aduk rata dan diamkan dalam kulkas selama minimal 2 jam atau semalaman.",
      "Setelah mengental membentuk puding, beri topping potongan mangga segar di atasnya.",
      "Nikmati dingin sebagai camilan bernutrisi tinggi."
    ]
  },
  {
    id: "rec_sn_5",
    name: "Irisan Semangka & Melon Dingin Daun Mint",
    category: "snack",
    calories: 90,
    protein: 2,
    carbs: 21,
    fat: 0,
    cookTime: "5 menit",
    image: "https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=600&q=80",
    tags: ["Hidrasi Tinggi", "Sangat Rendah Kalori", "Bebas Lemak"],
    description: "Potongan semangka merah dan melon manis dingin bertabur daun mint segar untuk hidrasi optimal di cuaca tropis.",
    ingredients: [
      { name: "Semangka Merah Manis Dadu", amount: "150", unit: "gram", category: "produce" },
      { name: "Melon Segar Dadu", amount: "100", unit: "gram", category: "produce" },
      { name: "Daun Mint Segar", amount: "5", unit: "lembar", category: "produce" }
    ],
    instructions: [
      "Potong dadu buah semangka dan melon dingin.",
      "Susun dalam mangkuk saji, taburkan daun mint cincang lembut di atasnya."
    ]
  },
  {
    id: "rec_sn_6",
    name: "Dua Butir Telur Rebus & Sambal Bawang Sehat",
    category: "snack",
    calories: 145,
    protein: 13,
    carbs: 2,
    fat: 10,
    cookTime: "10 menit",
    image: "https://images.unsplash.com/photo-1582722872445-44dc5f7e3c8f?auto=format&fit=crop&w=600&q=80",
    tags: ["Protein Murni", "Nol Karbo", "Keto Snack"],
    description: "Camilan pembangun otot padat protein: 2 butir telur ayam rebus matang dengan cocolan sambal bawang segar minyak zaitun.",
    ingredients: [
      { name: "Telur Ayam Segar", amount: "2", unit: "butir", category: "proteins" },
      { name: "Cabai Rawit & Bawang Putih Ulek", amount: "1", unit: "sdt", category: "spices" },
      { name: "Minyak Zaitun Ekstra Virgin", amount: "1/2", unit: "sdt", category: "spices" }
    ],
    instructions: [
      "Rebus telur dalam air mendidih selama 8-9 menit untuk kematangan sempurna.",
      "Kupas kulitnya, belah dua dan sajikan bersama sedikit cocolan sambal bawang segar."
    ]
  },
  {
    id: "rec_sn_7",
    name: "Chia Dark Chocolate Pudding Rendah Gula",
    category: "snack",
    calories: 165,
    protein: 6,
    carbs: 18,
    fat: 8,
    cookTime: "5 menit",
    image: "https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?auto=format&fit=crop&w=600&q=80",
    tags: ["Antioksidan Tinggi", "Vegan", "Mood Booster"],
    description: "Puding chia cokelat pekat dari bubuk kakao murni tanpa gula (dark cocoa), susu oat, dan pemanis stevia/madu alami.",
    ingredients: [
      { name: "Biji Chia (Chia Seeds)", amount: "2", unit: "sdm", category: "grains" },
      { name: "Bubuk Kakao Murni (Pure Dark Cocoa)", amount: "1", unit: "sdm", category: "spices" },
      { name: "Susu Oat / Almond", amount: "120", unit: "ml", category: "dairy" },
      { name: "Madu Alami Murni", amount: "1", unit: "sdt", category: "spices" }
    ],
    instructions: [
      "Aduk rata bubuk kakao, madu, dan susu oat hingga larut.",
      "Masukkan biji chia, aduk kembali dan dinginkan di kulkas hingga memadat.",
      "Sajikan dingin dengan aroma cokelat yang menggoda."
    ]
  },
  {
    id: "rec_sn_8",
    name: "Kacang Kenari & Keripik Apel Panggang Oven",
    category: "snack",
    calories: 155,
    protein: 5,
    carbs: 16,
    fat: 9,
    cookTime: "5 menit",
    image: "https://images.unsplash.com/photo-1599599810769-bcde5a160d32?auto=format&fit=crop&w=600&q=80",
    tags: ["Sehat Jantung", "Renyah", "Tanpa Minyak"],
    description: "Irisan tipis apel yang dipanggang kering renyah tanpa minyak bersama segenggam kacang kenari (walnut) kaya asam lemak omega-3.",
    ingredients: [
      { name: "Kacang Kenari / Walnuts", amount: "15", unit: "gram", category: "grains" },
      { name: "Keripik Apel Panggang Alami", amount: "20", unit: "gram", category: "produce" }
    ],
    instructions: [
      "Campurkan kacang walnut dan keripik apel panggang dalam mangkuk camilan.",
      "Nikmati kerenyahannya sebagai teman minum teh hijau sore hari."
    ]
  }
];

// Helper database resep berdasarkan ID
const RECIPE_MAP = RECIPES_DATA.reduce((acc, recipe) => {
  acc[recipe.id] = recipe;
  return acc;
}, {});

// Template Meal Plan 7 Hari (Mingguan)
const DEFAULT_WEEKLY_PLAN = {
  1: { // Senin
    dayName: "Senin",
    dateLabel: "Hari ke-1",
    meals: {
      breakfast: "rec_bf_1", // Oatmeal Apel
      lunch: "rec_lu_1",     // Dada Ayam Bakar Lemon
      dinner: "rec_dn_1",    // Sup Ikan Kakap Bening
      snack: "rec_sn_1"      // Greek Yogurt & Beri
    },
    consumed: { breakfast: true, lunch: true, dinner: false, snack: false }
  },
  2: { // Selasa
    dayName: "Selasa",
    dateLabel: "Hari ke-2",
    meals: {
      breakfast: "rec_bf_2", // Roti Gandum Alpukat
      lunch: "rec_lu_2",     // Gado-Gado Sehat
      dinner: "rec_dn_2",    // Pepes Tahu Jamur
      snack: "rec_sn_2"      // Kacang Almond & Apel
    },
    consumed: { breakfast: true, lunch: false, dinner: false, snack: false }
  },
  3: { // Rabu
    dayName: "Rabu",
    dateLabel: "Hari ke-3",
    meals: {
      breakfast: "rec_bf_3", // Green Smoothie Bowl
      lunch: "rec_lu_3",     // Salmon Quinoa Salad
      dinner: "rec_dn_3",    // Salad Mediterania Ayam
      snack: "rec_sn_3"      // Edamame Rebus
    },
    consumed: { breakfast: false, lunch: false, dinner: false, snack: false }
  },
  4: { // Kamis
    dayName: "Kamis",
    dateLabel: "Hari ke-4",
    meals: {
      breakfast: "rec_bf_4", // Omelet Putih Telur
      lunch: "rec_lu_4",     // Tumis Sapi Lada Hitam
      dinner: "rec_dn_4",    // Tumis Udang Buncis
      snack: "rec_sn_4"      // Puding Chia Mangga
    },
    consumed: { breakfast: false, lunch: false, dinner: false, snack: false }
  },
  5: { // Jumat
    dayName: "Jumat",
    dateLabel: "Hari ke-5",
    meals: {
      breakfast: "rec_bf_5", // Bubur Oat Gurih Ayam
      lunch: "rec_lu_5",     // Soto Ayam Bening
      dinner: "rec_dn_5",    // Capcay Seafood Kuah
      snack: "rec_sn_5"      // Semangka & Melon
    },
    consumed: { breakfast: false, lunch: false, dinner: false, snack: false }
  },
  6: { // Sabtu
    dayName: "Sabtu",
    dateLabel: "Hari ke-6",
    meals: {
      breakfast: "rec_bf_6", // Pancake Gandum Pisang
      lunch: "rec_lu_6",     // Poke Bowl Tuna
      dinner: "rec_dn_6",    // Zucchini Bolognese
      snack: "rec_sn_6"      // Dua Telur Rebus Sambal
    },
    consumed: { breakfast: false, lunch: false, dinner: false, snack: false }
  },
  7: { // Minggu
    dayName: "Minggu",
    dateLabel: "Hari ke-7",
    meals: {
      breakfast: "rec_bf_7", // Tortilla Wrap Telur
      lunch: "rec_lu_7",     // Pepes Ikan Kembung
      dinner: "rec_dn_7",    // Sup Tahu Kimchi Enoki
      snack: "rec_sn_7"      // Chia Dark Chocolate
    },
    consumed: { breakfast: false, lunch: false, dinner: false, snack: false }
  }
};

// Template 4 Pekan untuk Rencana Bulanan (Monthly Plan)
const DEFAULT_MONTHLY_PLAN = {
  week1: JSON.parse(JSON.stringify(DEFAULT_WEEKLY_PLAN)),
  week2: {
    1: { dayName: "Senin", dateLabel: "Pekan 2", meals: { breakfast: "rec_bf_2", lunch: "rec_lu_3", dinner: "rec_dn_1", snack: "rec_sn_2" }, consumed: {} },
    2: { dayName: "Selasa", dateLabel: "Pekan 2", meals: { breakfast: "rec_bf_4", lunch: "rec_lu_1", dinner: "rec_dn_3", snack: "rec_sn_3" }, consumed: {} },
    3: { dayName: "Rabu", dateLabel: "Pekan 2", meals: { breakfast: "rec_bf_5", lunch: "rec_lu_5", dinner: "rec_dn_5", snack: "rec_sn_5" }, consumed: {} },
    4: { dayName: "Kamis", dateLabel: "Pekan 2", meals: { breakfast: "rec_bf_3", lunch: "rec_lu_2", dinner: "rec_dn_4", snack: "rec_sn_4" }, consumed: {} },
    5: { dayName: "Jumat", dateLabel: "Pekan 2", meals: { breakfast: "rec_bf_6", lunch: "rec_lu_6", dinner: "rec_dn_8", snack: "rec_sn_6" }, consumed: {} },
    6: { dayName: "Sabtu", dateLabel: "Pekan 2", meals: { breakfast: "rec_bf_7", lunch: "rec_lu_7", dinner: "rec_dn_2", snack: "rec_sn_7" }, consumed: {} },
    7: { dayName: "Minggu", dateLabel: "Pekan 2", meals: { breakfast: "rec_bf_8", lunch: "rec_lu_8", dinner: "rec_dn_6", snack: "rec_sn_8" }, consumed: {} }
  },
  week3: {
    1: { dayName: "Senin", dateLabel: "Pekan 3", meals: { breakfast: "rec_bf_3", lunch: "rec_lu_1", dinner: "rec_dn_2", snack: "rec_sn_4" }, consumed: {} },
    2: { dayName: "Selasa", dateLabel: "Pekan 3", meals: { breakfast: "rec_bf_1", lunch: "rec_lu_3", dinner: "rec_dn_4", snack: "rec_sn_1" }, consumed: {} },
    3: { dayName: "Rabu", dateLabel: "Pekan 3", meals: { breakfast: "rec_bf_4", lunch: "rec_lu_2", dinner: "rec_dn_1", snack: "rec_sn_2" }, consumed: {} },
    4: { dayName: "Kamis", dateLabel: "Pekan 3", meals: { breakfast: "rec_bf_5", lunch: "rec_lu_4", dinner: "rec_dn_5", snack: "rec_sn_5" }, consumed: {} },
    5: { dayName: "Jumat", dateLabel: "Pekan 3", meals: { breakfast: "rec_bf_7", lunch: "rec_lu_6", dinner: "rec_dn_6", snack: "rec_sn_6" }, consumed: {} },
    6: { dayName: "Sabtu", dateLabel: "Pekan 3", meals: { breakfast: "rec_bf_2", lunch: "rec_lu_7", dinner: "rec_dn_8", snack: "rec_sn_3" }, consumed: {} },
    7: { dayName: "Minggu", dateLabel: "Pekan 3", meals: { breakfast: "rec_bf_8", lunch: "rec_lu_5", dinner: "rec_dn_7", snack: "rec_sn_8" }, consumed: {} }
  },
  week4: {
    1: { dayName: "Senin", dateLabel: "Pekan 4", meals: { breakfast: "rec_bf_4", lunch: "rec_lu_2", dinner: "rec_dn_3", snack: "rec_sn_3" }, consumed: {} },
    2: { dayName: "Selasa", dateLabel: "Pekan 4", meals: { breakfast: "rec_bf_2", lunch: "rec_lu_4", dinner: "rec_dn_1", snack: "rec_sn_1" }, consumed: {} },
    3: { dayName: "Rabu", dateLabel: "Pekan 4", meals: { breakfast: "rec_bf_1", lunch: "rec_lu_1", dinner: "rec_dn_4", snack: "rec_sn_2" }, consumed: {} },
    4: { dayName: "Kamis", dateLabel: "Pekan 4", meals: { breakfast: "rec_bf_6", lunch: "rec_lu_5", dinner: "rec_dn_7", snack: "rec_sn_7" }, consumed: {} },
    5: { dayName: "Jumat", dateLabel: "Pekan 4", meals: { breakfast: "rec_bf_5", lunch: "rec_lu_6", dinner: "rec_dn_5", snack: "rec_sn_5" }, consumed: {} },
    6: { dayName: "Sabtu", dateLabel: "Pekan 4", meals: { breakfast: "rec_bf_7", lunch: "rec_lu_8", dinner: "rec_dn_8", snack: "rec_sn_6" }, consumed: {} },
    7: { dayName: "Minggu", dateLabel: "Pekan 4", meals: { breakfast: "rec_bf_3", lunch: "rec_lu_3", dinner: "rec_dn_2", snack: "rec_sn_4" }, consumed: {} }
  }
};

// Kategori Bahan Belanja untuk Agregasi Cerdas
const GROCERY_CATEGORIES = {
  produce: { label: "Sayuran & Buah Segar", icon: "carrot", color: "emerald" },
  proteins: { label: "Sumber Protein (Ayam, Ikan, Daging, Telur, Tahu)", icon: "fish", color: "amber" },
  grains: { label: "Karbohidrat & Biji-Bijian Sehat", icon: "wheat", color: "yellow" },
  dairy: { label: "Susu, Yogurt & Alternatif Nabati", icon: "milk", color: "blue" },
  spices: { label: "Bumbu, Saus & Minyak Sehat", icon: "sparkles", color: "orange" }
};
