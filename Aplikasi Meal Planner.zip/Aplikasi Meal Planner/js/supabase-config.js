/**
 * GREEN DIET - Supabase Config Bridge
 * Memastikan koneksi Supabase langsung aktif baik saat dibuka lewat web server lokal maupun klik langsung index.html.
 */
window.SUPABASE_CONFIG = {
  url: "https://jatmdhswrsvqzuaucmoe.supabase.co",
  anonKey: "sb_publishable_Syu0HbTDVQX58yyWTCmCpQ_mHT7FSWl"
};
