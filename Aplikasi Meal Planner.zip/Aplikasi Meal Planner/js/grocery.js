/**
 * NutriPlan Green - Generator & Pengelola Daftar Belanja Otomatis (Smart Grocery List)
 * Mengumpulkan, mengelompokkan, dan menghitung seluruh bahan dari menu makanan yang dipilih.
 */

const GROCERY_CHECKLIST_KEY = "nutriplan_grocery_checked_items";
const GROCERY_CUSTOM_ITEMS_KEY = "nutriplan_grocery_custom_items";

class GroceryManager {
  constructor() {
    this.checkedItems = new Set();
    this.customItems = [];
    this.aggregationScope = "week"; // 'week' | 'month'

    this.loadChecklistState();
    this.listenToEvents();
  }

  // Muat status checklist dan item kustom dari localStorage
  loadChecklistState() {
    try {
      const storedChecked = localStorage.getItem(GROCERY_CHECKLIST_KEY);
      if (storedChecked) {
        this.checkedItems = new Set(JSON.parse(storedChecked));
      }

      const storedCustom = localStorage.getItem(GROCERY_CUSTOM_ITEMS_KEY);
      if (storedCustom) {
        this.customItems = JSON.parse(storedCustom);
      }
    } catch (e) {
      console.warn("Gagal memuat status belanja:", e);
    }
  }

  // Simpan status ke localStorage dan cloud Supabase
  saveChecklistState() {
    try {
      localStorage.setItem(GROCERY_CHECKLIST_KEY, JSON.stringify(Array.from(this.checkedItems)));
      localStorage.setItem(GROCERY_CUSTOM_ITEMS_KEY, JSON.stringify(this.customItems));

      // Simpan otomatis ke Supabase jika member cloud aktif
      const user = (typeof authManager !== "undefined") ? authManager.getUser() : null;
      if (user && user.isCloudUser && typeof supabaseService !== "undefined" && supabaseService.isConfigured) {
        supabaseService.saveGroceries(user.id, Array.from(this.checkedItems), this.customItems, this.aggregationScope);
      }
    } catch (e) {
      console.error("Gagal menyimpan checklist belanja:", e);
    }
  }

  // Sinkronisasi data daftar belanja pribadi member dari Supabase Cloud
  async syncUserGroceriesWithCloud(userId) {
    if (typeof supabaseService === "undefined" || !supabaseService.isConfigured) return;
    try {
      const cloudGroc = await supabaseService.getGroceries(userId);
      if (cloudGroc) {
        this.checkedItems = new Set(cloudGroc.checked_items || []);
        this.customItems = cloudGroc.custom_items || [];
        if (cloudGroc.scope) this.aggregationScope = cloudGroc.scope;
      } else {
        // Buat record awal di cloud
        await supabaseService.saveGroceries(userId, Array.from(this.checkedItems), this.customItems, this.aggregationScope);
      }
      this.renderGroceryList();
    } catch (err) {
      console.warn("Gagal sinkronisasi groceries dengan cloud:", err);
    }
  }

  // Reset daftar belanja saat logout
  resetToDefault() {
    this.checkedItems.clear();
    this.customItems = [];
    this.renderGroceryList();
  }

  listenToEvents() {
    window.addEventListener("nutriplan_plan_updated", () => {
      this.renderGroceryList();
    });
    window.addEventListener("greendiet_plan_updated", () => {
      this.renderGroceryList();
    });
  }

  // Kumpulkan semua resep yang aktif berdasarkan scope (Minggu ini atau Bulan ini)
  collectActiveRecipes() {
    const recipes = [];
    if (this.aggregationScope === "week") {
      // Ambil 7 hari dari rencana mingguan aktif
      const currentWeekData =
        mealPlanner.currentMode === "weekly"
          ? mealPlanner.weeklyPlan
          : mealPlanner.monthlyPlan[mealPlanner.selectedWeek] || mealPlanner.weeklyPlan;

      for (let day = 1; day <= 7; day++) {
        const meals = currentWeekData[day]?.meals || {};
        Object.values(meals).forEach(recipeId => {
          if (RECIPE_MAP[recipeId]) {
            recipes.push(RECIPE_MAP[recipeId]);
          }
        });
      }
    } else {
      // Ambil seluruh 4 pekan bulanan
      const mPlan = mealPlanner.monthlyPlan;
      Object.keys(mPlan).forEach(weekKey => {
        const week = mPlan[weekKey];
        for (let day = 1; day <= 7; day++) {
          const meals = week[day]?.meals || {};
          Object.values(meals).forEach(recipeId => {
            if (RECIPE_MAP[recipeId]) {
              recipes.push(RECIPE_MAP[recipeId]);
            }
          });
        }
      });
    }
    return recipes;
  }

  // Agregasi bahan makanan dengan pengelompokan pintar
  generateAggregatedIngredients() {
    const recipes = this.collectActiveRecipes();
    const categoriesMap = {
      produce: [],
      proteins: [],
      grains: [],
      dairy: [],
      spices: []
    };

    // Dictionary untuk agregasi per nama bahan
    const itemDict = {};

    recipes.forEach(recipe => {
      recipe.ingredients.forEach(ing => {
        const key = ing.name.toLowerCase().trim();
        if (!itemDict[key]) {
          itemDict[key] = {
            id: "ing_" + key.replace(/[^a-z0-9]/g, "_"),
            name: ing.name,
            category: ing.category || "spices",
            amounts: [],
            sources: new Set()
          };
        }
        itemDict[key].amounts.push(`${ing.amount} ${ing.unit}`.trim());
        itemDict[key].sources.add(recipe.name);
      });
    });

    // Masukkan ke dalam kategori
    Object.values(itemDict).forEach(item => {
      const cat = categoriesMap[item.category] ? item.category : "spices";
      // Format ringkasan jumlah
      const amountSummary = this.formatAmountSummary(item.amounts);
      categoriesMap[cat].push({
        id: item.id,
        name: item.name,
        amount: amountSummary,
        recipesCount: item.sources.size,
        category: cat,
        isCustom: false
      });
    });

    // Masukkan item kustom yang ditambah manual oleh pengguna
    this.customItems.forEach(ci => {
      const cat = categoriesMap[ci.category] ? ci.category : "produce";
      categoriesMap[cat].push({
        id: ci.id,
        name: ci.name,
        amount: ci.amount || "1 buah/paket",
        recipesCount: 0,
        category: cat,
        isCustom: true
      });
    });

    return categoriesMap;
  }

  // Helper untuk merangkum takaran bahan
  formatAmountSummary(amounts) {
    if (!amounts || amounts.length === 0) return "Secukupnya";
    if (amounts.length === 1) return amounts[0];

    // Coba hitung penjumlahan jika satuan numerik murni (misal: "180 gram" + "150 gram")
    let totalNumeric = 0;
    let unit = "";
    let canSum = true;

    for (const amt of amounts) {
      const match = amt.match(/^([\d\.]+)\s*(.*)$/);
      if (match) {
        const val = parseFloat(match[1]);
        const u = match[2].trim().toLowerCase();
        if (unit === "") unit = u;
        if (unit === u) {
          totalNumeric += val;
        } else {
          canSum = false;
          break;
        }
      } else {
        canSum = false;
        break;
      }
    }

    if (canSum && totalNumeric > 0) {
      return `${totalNumeric} ${unit}`;
    }

    return `${amounts.length}x penyajian (${amounts.slice(0, 2).join(", ")}${amounts.length > 2 ? "..." : ""})`;
  }

  // Toggle item checklist
  toggleItem(itemId) {
    if (this.checkedItems.has(itemId)) {
      this.checkedItems.delete(itemId);
    } else {
      this.checkedItems.add(itemId);
    }
    this.saveChecklistState();
    this.renderGroceryList();
  }

  // Tambah item belanja manual
  addCustomItem(name, amount, category) {
    if (!name.trim()) return;
    const newItem = {
      id: "custom_" + Date.now(),
      name: name.trim(),
      amount: amount.trim() || "1 paket",
      category: category || "produce"
    };
    this.customItems.push(newItem);
    this.saveChecklistState();
    this.renderGroceryList();
    showToast(`Bahan "${newItem.name}" ditambahkan ke daftar belanja!`, "success");
  }

  // Hapus item kustom
  removeCustomItem(itemId) {
    this.customItems = this.customItems.filter(i => i.id !== itemId);
    this.checkedItems.delete(itemId);
    this.saveChecklistState();
    this.renderGroceryList();
  }

  // Reset semua checklist
  resetChecklist() {
    this.checkedItems.clear();
    this.saveChecklistState();
    this.renderGroceryList();
    showToast("Semua checklist belanja telah di-reset.", "info");
  }

  // Ganti periode agregasi (Pekan ini / Sebulan)
  setScope(scope) {
    this.aggregationScope = scope;
    const btnWeek = document.getElementById("scope-week-btn");
    const btnMonth = document.getElementById("scope-month-btn");

    if (scope === "week") {
      btnWeek?.classList.add("bg-emerald-600", "text-white");
      btnWeek?.classList.remove("text-slate-600", "bg-white");
      btnMonth?.classList.remove("bg-emerald-600", "text-white");
      btnMonth?.classList.add("text-slate-600", "bg-white");
    } else {
      btnMonth?.classList.add("bg-emerald-600", "text-white");
      btnMonth?.classList.remove("text-slate-600", "bg-white");
      btnWeek?.classList.remove("bg-emerald-600", "text-white");
      btnWeek?.classList.add("text-slate-600", "bg-white");
    }

    this.renderGroceryList();
  }

  // Render antarmuka daftar belanja ke DOM
  renderGroceryList() {
    const container = document.getElementById("grocery-categories-container");
    if (!container) return;

    const categoriesData = this.generateAggregatedIngredients();

    let totalItems = 0;
    let checkedCount = 0;

    Object.values(categoriesData).forEach(items => {
      totalItems += items.length;
      items.forEach(it => {
        if (this.checkedItems.has(it.id)) checkedCount++;
      });
    });

    // Update Progress Bar & Counter
    const progressEl = document.getElementById("grocery-progress-bar");
    const countEl = document.getElementById("grocery-count-label");
    const percentageEl = document.getElementById("grocery-percentage-label");

    const pct = totalItems > 0 ? Math.round((checkedCount / totalItems) * 100) : 0;
    if (progressEl) progressEl.style.width = `${pct}%`;
    if (countEl) countEl.textContent = `${checkedCount} dari ${totalItems} item terbeli`;
    if (percentageEl) percentageEl.textContent = `${pct}% Selesai`;

    // Render Per Kategori
    container.innerHTML = Object.entries(GROCERY_CATEGORIES)
      .map(([catKey, catMeta]) => {
        const items = categoriesData[catKey] || [];
        if (items.length === 0) return "";

        const catCheckedCount = items.filter(it => this.checkedItems.has(it.id)).length;

        return `
          <div class="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden mb-5">
            <!-- Header Kategori -->
            <div class="px-5 py-3.5 bg-slate-50/80 border-b border-slate-100 flex items-center justify-between">
              <div class="flex items-center gap-2.5">
                <span class="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-sm">
                  <i data-lucide="${catMeta.icon}" class="w-4 h-4"></i>
                </span>
                <div>
                  <h3 class="font-bold text-slate-800 text-sm sm:text-base">${catMeta.label}</h3>
                  <span class="text-xs text-slate-600">${items.length} jenis bahan</span>
                </div>
              </div>
              <span class="text-xs font-semibold px-2.5 py-1 rounded-full ${
                catCheckedCount === items.length
                  ? "bg-emerald-100 text-emerald-800"
                  : "bg-slate-200/70 text-slate-600"
              }">
                ${catCheckedCount}/${items.length} Terbeli
              </span>
            </div>

            <!-- List Item Bahan -->
            <div class="divide-y divide-slate-100">
              ${items
                .map(item => {
                  const isChecked = this.checkedItems.has(item.id);
                  return `
                    <div class="px-5 py-3 flex items-center justify-between gap-3 hover:bg-slate-50/50 transition-colors ${
                      isChecked ? "bg-emerald-50/20" : ""
                    }">
                      <label class="flex items-center gap-3 cursor-pointer flex-1 min-w-0">
                        <input 
                          type="checkbox" 
                          ${isChecked ? "checked" : ""} 
                          onchange="groceryManager.toggleItem('${item.id}')"
                          class="w-5 h-5 rounded-lg text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer"
                        />
                        <div class="flex-1 min-w-0">
                          <span class="text-sm font-medium ${
                            isChecked ? "line-through text-slate-600 font-normal" : "text-slate-800"
                          } block truncate">
                            ${item.name}
                          </span>
                          ${
                            item.recipesCount > 1
                              ? `<span class="text-[11px] text-emerald-600">Digunakan dalam ${item.recipesCount} menu</span>`
                              : ""
                          }
                        </div>
                      </label>

                      <div class="flex items-center gap-2 shrink-0">
                        <span class="text-xs font-semibold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-lg">
                          ${item.amount}
                        </span>
                        ${
                          item.isCustom
                            ? `<button onclick="groceryManager.removeCustomItem('${item.id}')" class="text-slate-500 hover:text-rose-500 p-1 rounded-lg transition-colors" title="Hapus bahan manual">
                                <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                              </button>`
                            : ""
                        }
                      </div>
                    </div>
                  `;
                })
                .join("")}
            </div>
          </div>
        `;
      })
      .join("");

    if (window.lucide) window.lucide.createIcons();
  }
}

const groceryManager = new GroceryManager();
