/**
 * GREEN DIET - Modul Ekspor PDF & Cetak Dokumen Rapi
 * Menghasilkan dokumen PDF profesional untuk Meal Plan dan Daftar Belanja.
 */

class PDFExportManager {
  constructor() {
    this.isGenerating = false;
  }

  // Format tanggal bahasa Indonesia
  getFormattedDate() {
    return new Date().toLocaleDateString("id-ID", {
      day: "numeric",
      month: "long",
      year: "numeric"
    });
  }

  // Ekspor Jadwal Meal Plan Mingguan ke PDF
  exportMealPlanPDF() {
    if (this.isGenerating) return;
    this.isGenerating = true;
    showToast("Sedang menyiapkan dokumen PDF Meal Plan...", "info");

    const currentUser = authManager.getUser();
    const userTargetCalories = currentUser?.healthProfile?.targetCalories || 1600;
    const plan = mealPlanner.weeklyPlan;

    // Buat elemen terisolasi khusus cetak
    const printContainer = document.createElement("div");
    printContainer.id = "greendiet-pdf-export-temp";
    printContainer.className = "p-8 bg-white text-slate-800 font-sans";
    printContainer.style.width = "800px";

    let rowsHtml = "";
    const days = [1, 2, 3, 4, 5, 6, 7];

    days.forEach(d => {
      const dayData = plan[d];
      const bf = RECIPE_MAP[dayData.meals.breakfast];
      const lu = RECIPE_MAP[dayData.meals.lunch];
      const dn = RECIPE_MAP[dayData.meals.dinner];
      const sn = RECIPE_MAP[dayData.meals.snack];

      const dayCal = (bf?.calories || 0) + (lu?.calories || 0) + (dn?.calories || 0) + (sn?.calories || 0);

      rowsHtml += `
        <tr style="border-bottom: 1px solid #e2e8f0; font-size: 11px;">
          <td style="padding: 10px 8px; font-weight: bold; color: #047857; vertical-align: top;">
            ${dayData.dayName}
            <div style="font-size: 9px; color: #64748b; font-weight: normal;">${dayData.dateLabel}</div>
          </td>
          <td style="padding: 10px 8px; vertical-align: top;">
            <strong>${bf?.name || "-"}</strong>
            <div style="color: #059669; font-size: 10px;">${bf?.calories || 0} kcal</div>
          </td>
          <td style="padding: 10px 8px; vertical-align: top;">
            <strong>${lu?.name || "-"}</strong>
            <div style="color: #059669; font-size: 10px;">${lu?.calories || 0} kcal</div>
          </td>
          <td style="padding: 10px 8px; vertical-align: top;">
            <strong>${dn?.name || "-"}</strong>
            <div style="color: #059669; font-size: 10px;">${dn?.calories || 0} kcal</div>
          </td>
          <td style="padding: 10px 8px; vertical-align: top;">
            <strong>${sn?.name || "-"}</strong>
            <div style="color: #059669; font-size: 10px;">${sn?.calories || 0} kcal</div>
          </td>
          <td style="padding: 10px 8px; text-align: center; vertical-align: top; font-weight: bold; color: #0f172a; background: #f8fafc;">
            ${dayCal} kcal
          </td>
        </tr>
      `;
    });

    printContainer.innerHTML = `
      <div style="border-bottom: 3px solid #059669; padding-bottom: 16px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
        <div>
          <div style="display: flex; align-items: center; gap: 8px;">
            <div style="width: 32px; height: 32px; background: #059669; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 16px;">🌱</div>
            <h1 style="font-size: 22px; font-weight: bold; color: #065f46; margin: 0;">GREEN DIET</h1>
          </div>
          <p style="font-size: 12px; color: #64748b; margin-top: 4px;">Rencana Makan Diet Sehat Mingguan & Panduan Nutrisi</p>
        </div>
        <div style="text-align: right; font-size: 11px; color: #475569;">
          <div>Member: <strong style="color: #0f172a;">${currentUser?.name || "Member Green Diet"}</strong></div>
          <div>Target Kalori: <strong style="color: #059669;">${userTargetCalories} kcal / hari</strong></div>
          <div>Tanggal Cetak: ${this.getFormattedDate()}</div>
        </div>
      </div>

      <!-- Ringkasan Profil Singkat -->
      <div style="background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 10px; padding: 12px 16px; margin-bottom: 20px; display: flex; justify-content: space-around; font-size: 12px;">
        <div>Target Diet: <strong style="color: #065f46;">Defisit Kalori Sehat (-500 kcal)</strong></div>
        <div>Rasio Makro: <strong style="color: #065f46;">Karbo 45% | Protein 30% | Lemak 25%</strong></div>
        <div>Total Menu: <strong style="color: #065f46;">28 Waktu Makan Terjadwal</strong></div>
      </div>

      <!-- Tabel Jadwal -->
      <table style="width: 100%; border-collapse: collapse; text-align: left; margin-bottom: 24px;">
        <thead>
          <tr style="background: #059669; color: white; font-size: 11px;">
            <th style="padding: 10px 8px; border-radius: 6px 0 0 0; width: 10%;">Hari</th>
            <th style="padding: 10px 8px; width: 22%;">Sarapan (07:00)</th>
            <th style="padding: 10px 8px; width: 22%;">Makan Siang (12:30)</th>
            <th style="padding: 10px 8px; width: 22%;">Makan Malam (19:00)</th>
            <th style="padding: 10px 8px; width: 14%;">Camilan Sehat</th>
            <th style="padding: 10px 8px; width: 10%; text-align: center; border-radius: 0 6px 0 0;">Total</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtml}
        </tbody>
      </table>

      <!-- Footer Catatan Nutrisi -->
      <div style="border-top: 1px solid #e2e8f0; padding-top: 12px; display: flex; justify-content: space-between; font-size: 10px; color: #94a3b8;">
        <div>💡 Tip Diet: Minum minimal 2-2.5 liter air putih setiap hari dan pertahankan jam tidur teratur.</div>
        <div>Dokumen dibuat otomatis oleh GREEN DIET</div>
      </div>
    `;

    document.body.appendChild(printContainer);

    // Konfigurasi html2pdf
    const opt = {
      margin: 10,
      filename: `Green_Diet_Meal_Plan_${new Date().toISOString().slice(0, 10)}.pdf`,
      image: { type: "jpeg", quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true },
      jsPDF: { unit: "mm", format: "a4", orientation: "landscape" }
    };

    if (window.html2pdf) {
      window
        .html2pdf()
        .set(opt)
        .from(printContainer)
        .save()
        .then(() => {
          document.body.removeChild(printContainer);
          this.isGenerating = false;
          showToast("PDF Meal Plan berhasil diunduh!", "success");
        })
        .catch(err => {
          console.error("Gagal html2pdf:", err);
          document.body.removeChild(printContainer);
          this.isGenerating = false;
          window.print();
        });
    } else {
      document.body.removeChild(printContainer);
      this.isGenerating = false;
      window.print();
    }
  }

  // Ekspor Daftar Belanja Otomatis ke PDF
  exportGroceryPDF() {
    if (this.isGenerating) return;
    this.isGenerating = true;
    showToast("Sedang menyiapkan dokumen PDF Daftar Belanja...", "info");

    const currentUser = authManager.getUser();
    const categoriesData = groceryManager.generateAggregatedIngredients();
    const checkedItems = groceryManager.checkedItems;

    const printContainer = document.createElement("div");
    printContainer.id = "greendiet-grocery-pdf-temp";
    printContainer.className = "p-8 bg-white text-slate-800 font-sans";
    printContainer.style.width = "750px";

    let categoriesHtml = "";

    Object.entries(GROCERY_CATEGORIES).forEach(([catKey, catMeta]) => {
      const items = categoriesData[catKey] || [];
      if (items.length === 0) return;

      const itemsListHtml = items
        .map(it => {
          const isDone = checkedItems.has(it.id);
          return `
            <div style="display: flex; align-items: center; justify-content: space-between; padding: 6px 0; border-bottom: 1px dashed #f1f5f9; font-size: 11px;">
              <div style="display: flex; align-items: center; gap: 8px;">
                <span style="display: inline-block; width: 14px; height: 14px; border: 1.5px solid ${isDone ? "#059669" : "#cbd5e1"}; border-radius: 4px; background: ${isDone ? "#059669" : "transparent"}; color: white; text-align: center; line-height: 14px; font-size: 10px;">${isDone ? "✓" : ""}</span>
                <span style="${isDone ? "text-decoration: line-through; color: #94a3b8;" : "color: #1e293b;"}">${it.name}</span>
              </div>
              <span style="color: #64748b; font-weight: 500; font-size: 10px; background: #f8fafc; padding: 2px 6px; border-radius: 4px;">${it.amount}</span>
            </div>
          `;
        })
        .join("");

      categoriesHtml += `
        <div style="margin-bottom: 16px; break-inside: avoid;">
          <div style="background: #f0fdf4; border-left: 4px solid #059669; padding: 6px 10px; font-weight: bold; font-size: 12px; color: #065f46; margin-bottom: 8px;">
            ${catMeta.label} (${items.length} bahan)
          </div>
          <div style="padding-left: 8px;">
            ${itemsListHtml}
          </div>
        </div>
      `;
    });

    printContainer.innerHTML = `
      <div style="border-bottom: 3px solid #059669; padding-bottom: 14px; margin-bottom: 18px; display: flex; justify-content: space-between; align-items: center;">
        <div>
          <div style="display: flex; align-items: center; gap: 8px;">
            <div style="width: 28px; height: 28px; background: #059669; border-radius: 6px; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">🛒</div>
            <h1 style="font-size: 20px; font-weight: bold; color: #065f46; margin: 0;">GREEN DIET - Daftar Belanja</h1>
          </div>
          <p style="font-size: 11px; color: #64748b; margin-top: 3px;">Kompilasi Bahan Belanja Otomatis untuk Meal Plan Diet</p>
        </div>
        <div style="text-align: right; font-size: 11px; color: #475569;">
          <div>Member: <strong>${currentUser?.name || "Member Green Diet"}</strong></div>
          <div>Periode: <strong>${groceryManager.aggregationScope === "week" ? "Pekan Aktif (7 Hari)" : "Satu Bulan Penuh"}</strong></div>
          <div>Tanggal: ${this.getFormattedDate()}</div>
        </div>
      </div>

      <!-- Konten Daftar Belanja -->
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
        ${categoriesHtml}
      </div>

      <!-- Footer -->
      <div style="border-top: 1px solid #e2e8f0; margin-top: 24px; padding-top: 10px; display: flex; justify-content: space-between; font-size: 10px; color: #94a3b8;">
        <div>Bawalah tas belanja ramah lingkungan saat berbelanja bahan segar.</div>
        <div>GREEN DIET &copy; 2026</div>
      </div>
    `;

    document.body.appendChild(printContainer);

    const opt = {
      margin: 10,
      filename: `Green_Diet_Daftar_Belanja_${new Date().toISOString().slice(0, 10)}.pdf`,
      image: { type: "jpeg", quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true },
      jsPDF: { unit: "mm", format: "a4", orientation: "portrait" }
    };

    if (window.html2pdf) {
      window
        .html2pdf()
        .set(opt)
        .from(printContainer)
        .save()
        .then(() => {
          document.body.removeChild(printContainer);
          this.isGenerating = false;
          showToast("PDF Daftar Belanja berhasil diunduh!", "success");
        })
        .catch(err => {
          console.error("Gagal html2pdf:", err);
          document.body.removeChild(printContainer);
          this.isGenerating = false;
          window.print();
        });
    } else {
      document.body.removeChild(printContainer);
      this.isGenerating = false;
      window.print();
    }
  }
}

const pdfExportManager = new PDFExportManager();
