/**
 * NutriPlan Green - Modul Perencana Makanan (Weekly & Monthly Meal Planner)
 * Mengatur tampilan mingguan/bulanan, pergantian menu (swap), pelacakan konsumsi, dan detail resep.
 */

const PLANNER_STORAGE_KEY = "nutriplan_active_plan";
const PLANNER_MODE_KEY = "nutriplan_view_mode";

class MealPlanner {
  constructor() {
    this.currentMode = "weekly"; // 'weekly' | 'monthly'
    this.selectedDay = 1; // 1 = Senin, ..., 7 = Minggu
    this.selectedWeek = "week1"; // 'week1' | 'week2' | 'week3' | 'week4'
    this.weeklyPlan = null;
    this.monthlyPlan = null;

    // State untuk modal pergantian menu (swap)
    this.activeSwapContext = null; // { day, slot, currentRecipeId }

    this.loadPlanData();
  }

  // Muat data jadwal makanan dari localStorage atau gunakan data contoh default
  loadPlanData() {
    try {
      const storedPlan = localStorage.getItem(PLANNER_STORAGE_KEY);
      if (storedPlan) {
        const parsed = JSON.parse(storedPlan);
        this.weeklyPlan = parsed.weekly || JSON.parse(JSON.stringify(DEFAULT_WEEKLY_PLAN));
        this.monthlyPlan = parsed.monthly || JSON.parse(JSON.stringify(DEFAULT_MONTHLY_PLAN));
      } else {
        this.weeklyPlan = JSON.parse(JSON.stringify(DEFAULT_WEEKLY_PLAN));
        this.monthlyPlan = JSON.parse(JSON.stringify(DEFAULT_MONTHLY_PLAN));
        this.savePlanData();
      }

      const storedMode = localStorage.getItem(PLANNER_MODE_KEY);
      if (storedMode) this.currentMode = storedMode;
    } catch (e) {
      this.weeklyPlan = JSON.parse(JSON.stringify(DEFAULT_WEEKLY_PLAN));
      this.monthlyPlan = JSON.parse(JSON.stringify(DEFAULT_MONTHLY_PLAN));
    }
  }

  // Simpan data ke localStorage dan cloud Supabase
  savePlanData() {
    try {
      localStorage.setItem(
        PLANNER_STORAGE_KEY,
        JSON.stringify({
          weekly: this.weeklyPlan,
          monthly: this.monthlyPlan
        })
      );

      // Simpan otomatis ke Supabase database jika member cloud sedang aktif
      const user = (typeof authManager !== "undefined") ? authManager.getUser() : null;
      if (user && user.isCloudUser && typeof supabaseService !== "undefined" && supabaseService.isConfigured) {
        supabaseService.saveMealPlan(user.id, this.weeklyPlan, this.monthlyPlan, this.currentMode);
      }

      // Trigger event agar daftar belanja otomatis diperbarui
      window.dispatchEvent(new CustomEvent("nutriplan_plan_updated"));
      window.dispatchEvent(new CustomEvent("greendiet_plan_updated"));
    } catch (e) {
      console.error("Gagal menyimpan rencana makan:", e);
    }
  }

  // Sinkronisasi data meal plan pribadi member dari Supabase Cloud
  async syncUserPlanWithCloud(userId) {
    if (typeof supabaseService === "undefined" || !supabaseService.isConfigured) return;
    try {
      const cloudPlan = await supabaseService.getMealPlan(userId);
      if (cloudPlan && cloudPlan.weekly_data) {
        this.weeklyPlan = cloudPlan.weekly_data;
        if (cloudPlan.monthly_data) this.monthlyPlan = cloudPlan.monthly_data;
        if (cloudPlan.plan_mode) this.currentMode = cloudPlan.plan_mode;
      } else {
        // Belum ada data di cloud untuk user baru ini -> Simpan template awal
        await supabaseService.saveMealPlan(userId, this.weeklyPlan, this.monthlyPlan, this.currentMode);
      }
      this.renderDayView();
      window.dispatchEvent(new CustomEvent("greendiet_plan_updated"));
    } catch (err) {
      console.warn("Gagal sinkronisasi meal plan dengan cloud:", err);
    }
  }

  // Reset tampilan ke template default saat logout
  resetToDefaultTemplate() {
    this.weeklyPlan = JSON.parse(JSON.stringify(DEFAULT_WEEKLY_PLAN));
    this.monthlyPlan = JSON.parse(JSON.stringify(DEFAULT_MONTHLY_PLAN));
    this.renderDayView();
    window.dispatchEvent(new CustomEvent("greendiet_plan_updated"));
  }

  // Ambil data hari aktif berdasarkan mode tampilan
  getActiveDayData(dayNumber = this.selectedDay) {
    if (this.currentMode === "weekly") {
      return this.weeklyPlan[dayNumber] || this.weeklyPlan[1];
    } else {
      const weekData = this.monthlyPlan[this.selectedWeek] || this.monthlyPlan.week1;
      return weekData[dayNumber] || weekData[1];
    }
  }

  // Ganti hari yang dipilih
  setSelectedDay(dayNumber) {
    this.selectedDay = parseInt(dayNumber, 10);
    this.renderDayView();
  }

  // Ganti pekan bulanan yang dipilih
  setSelectedWeek(weekKey) {
    this.selectedWeek = weekKey;
    this.renderDayView();
    this.renderMonthOverview();
  }

  // Ganti mode tampilan (Mingguan vs Bulanan)
  setViewMode(mode) {
    this.currentMode = mode;
    localStorage.setItem(PLANNER_MODE_KEY, mode);
    this.updateModeUI();
    this.renderDayView();
    if (mode === "monthly") {
      this.renderMonthOverview();
    }
  }

  // Update elemen toggle mode di UI
  updateModeUI() {
    const btnWeekly = document.getElementById("btn-mode-weekly");
    const btnMonthly = document.getElementById("btn-mode-monthly");
    const monthlySelector = document.getElementById("monthly-week-selector");
    const monthOverviewSection = document.getElementById("month-overview-container");

    if (this.currentMode === "weekly") {
      btnWeekly?.classList.add("bg-emerald-600", "text-white", "shadow-md");
      btnWeekly?.classList.remove("text-slate-600", "hover:bg-slate-100");
      btnMonthly?.classList.remove("bg-emerald-600", "text-white", "shadow-md");
      btnMonthly?.classList.add("text-slate-600", "hover:bg-slate-100");
      monthlySelector?.classList.add("hidden");
      monthOverviewSection?.classList.add("hidden");
    } else {
      btnMonthly?.classList.add("bg-emerald-600", "text-white", "shadow-md");
      btnMonthly?.classList.remove("text-slate-600", "hover:bg-slate-100");
      btnWeekly?.classList.remove("bg-emerald-600", "text-white", "shadow-md");
      btnWeekly?.classList.add("text-slate-600", "hover:bg-slate-100");
      monthlySelector?.classList.remove("hidden");
      monthOverviewSection?.classList.remove("hidden");
    }
  }

  // Toggle status makanan yang sudah dikonsumsi
  toggleConsumed(slot, day = this.selectedDay) {
    let dayData;
    if (this.currentMode === "weekly") {
      dayData = this.weeklyPlan[day];
    } else {
      dayData = this.monthlyPlan[this.selectedWeek][day];
    }

    if (!dayData.consumed) dayData.consumed = {};
    dayData.consumed[slot] = !dayData.consumed[slot];

    this.savePlanData();
    this.renderDayView();

    // Efek perayaan jika semua waktu makan hari ini selesai dicentang
    const allDone = ["breakfast", "lunch", "dinner", "snack"].every(s => dayData.consumed[s]);
    if (allDone && typeof confetti === "function") {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.8 },
        colors: ["#10b981", "#34d399", "#059669", "#6ee7b7"]
      });
      showToast("Selamat! Semua menu makanan sehat hari ini tuntas dikonsumsi! 🎉", "success");
    }
  }

  // Ganti menu yang dipilih dengan resep baru
  swapRecipe(newRecipeId) {
    if (!this.activeSwapContext) return;
    const { day, slot } = this.activeSwapContext;

    if (this.currentMode === "weekly") {
      this.weeklyPlan[day].meals[slot] = newRecipeId;
      if (this.weeklyPlan[day].consumed) {
        this.weeklyPlan[day].consumed[slot] = false;
      }
    } else {
      this.monthlyPlan[this.selectedWeek][day].meals[slot] = newRecipeId;
      if (this.monthlyPlan[this.selectedWeek][day].consumed) {
        this.monthlyPlan[this.selectedWeek][day].consumed[slot] = false;
      }
    }

    this.savePlanData();
    this.renderDayView();
    this.closeSwapModal();
    showToast("Menu berhasil diganti! Daftar belanja otomatis disesuaikan.", "success");
  }

  // Buka modal pergantian menu
  openSwapModal(slot, day = this.selectedDay) {
    const dayData = this.getActiveDayData(day);
    const currentRecipeId = dayData.meals[slot];
    this.activeSwapContext = { day, slot, currentRecipeId };

    const slotNames = {
      breakfast: "Sarapan Pagi",
      lunch: "Makan Siang",
      dinner: "Makan Malam",
      snack: "Camilan Sehat"
    };

    const titleEl = document.getElementById("swap-modal-title");
    if (titleEl) {
      titleEl.textContent = `Ganti Menu ${slotNames[slot]} (${dayData.dayName})`;
    }

    // Filter resep sesuai kategori waktu makan
    this.renderSwapRecipesList(slot, currentRecipeId);

    const modal = document.getElementById("swap-recipe-modal");
    modal?.classList.remove("hidden");
    modal?.classList.add("flex");
  }

  closeSwapModal() {
    const modal = document.getElementById("swap-recipe-modal");
    modal?.classList.add("hidden");
    modal?.classList.remove("flex");
    this.activeSwapContext = null;
  }

  // Render daftar resep alternatif di modal swap
  renderSwapRecipesList(category, currentId, filterTag = "") {
    const container = document.getElementById("swap-recipes-container");
    if (!container) return;

    let available = RECIPES_DATA.filter(r => r.category === category);
    if (filterTag) {
      available = available.filter(r => r.tags.some(t => t.toLowerCase().includes(filterTag.toLowerCase())));
    }

    container.innerHTML = available
      .map(recipe => {
        const isCurrent = recipe.id === currentId;
        return `
          <div class="border rounded-2xl p-4 transition-all duration-200 ${
            isCurrent
              ? "border-emerald-500 bg-emerald-50/50 ring-2 ring-emerald-500/30"
              : "border-slate-200 hover:border-emerald-300 hover:shadow-md bg-white"
          } flex flex-col sm:flex-row gap-4 items-center">
            <img src="${recipe.image}" alt="${recipe.name}" class="w-full sm:w-28 h-24 object-cover rounded-xl shrink-0" />
            <div class="flex-1 min-w-0 text-left">
              <div class="flex items-center gap-2 flex-wrap mb-1">
                ${recipe.tags
                  .map(
                    t =>
                      `<span class="px-2 py-0.5 text-xs font-medium rounded-full bg-emerald-100 text-emerald-800">${t}</span>`
                  )
                  .join("")}
                <span class="text-xs text-slate-500 flex items-center gap-1">
                  <i data-lucide="clock" class="w-3 h-3"></i> ${recipe.cookTime}
                </span>
              </div>
              <h4 class="font-bold text-slate-800 text-base leading-snug truncate">${recipe.name}</h4>
              <p class="text-xs text-slate-500 line-clamp-1 mt-0.5">${recipe.description}</p>
              
              <div class="flex items-center gap-3 mt-2 text-xs font-medium text-slate-600">
                <span class="font-bold text-emerald-600">${recipe.calories} kcal</span>
                <span>P: ${recipe.protein}g</span>
                <span>K: ${recipe.carbs}g</span>
                <span>L: ${recipe.fat}g</span>
              </div>
            </div>

            <div class="shrink-0 w-full sm:w-auto">
              ${
                isCurrent
                  ? `<span class="inline-flex items-center justify-center w-full sm:w-auto px-4 py-2 text-xs font-semibold text-emerald-700 bg-emerald-100 rounded-xl">Menu Aktif</span>`
                  : `<button onclick="mealPlanner.swapRecipe('${recipe.id}')" class="w-full sm:w-auto px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-medium text-xs rounded-xl shadow-sm transition-colors flex items-center justify-center gap-1">
                      <i data-lucide="check" class="w-4 h-4"></i> Pilih Menu Ini
                    </button>`
              }
            </div>
          </div>
        `;
      })
      .join("");

    if (window.lucide) window.lucide.createIcons();
  }

  // Tampilkan Detail Resep Lengkap di Modal
  openRecipeDetail(recipeId) {
    const recipe = RECIPE_MAP[recipeId];
    if (!recipe) return;

    const modal = document.getElementById("recipe-detail-modal");
    const titleEl = document.getElementById("recipe-modal-title");
    const imageEl = document.getElementById("recipe-modal-image");
    const descEl = document.getElementById("recipe-modal-desc");
    const caloriesEl = document.getElementById("recipe-modal-calories");
    const proteinEl = document.getElementById("recipe-modal-protein");
    const carbsEl = document.getElementById("recipe-modal-carbs");
    const fatEl = document.getElementById("recipe-modal-fat");
    const cookTimeEl = document.getElementById("recipe-modal-time");
    const tagsContainer = document.getElementById("recipe-modal-tags");
    const ingredientsContainer = document.getElementById("recipe-modal-ingredients");
    const instructionsContainer = document.getElementById("recipe-modal-instructions");

    if (titleEl) titleEl.textContent = recipe.name;
    if (imageEl) imageEl.src = recipe.image;
    if (descEl) descEl.textContent = recipe.description;
    if (caloriesEl) caloriesEl.textContent = `${recipe.calories} kcal`;
    if (proteinEl) proteinEl.textContent = `${recipe.protein}g`;
    if (carbsEl) carbsEl.textContent = `${recipe.carbs}g`;
    if (fatEl) fatEl.textContent = `${recipe.fat}g`;
    if (cookTimeEl) cookTimeEl.textContent = recipe.cookTime;

    if (tagsContainer) {
      tagsContainer.innerHTML = recipe.tags
        .map(t => `<span class="px-2.5 py-1 text-xs font-semibold rounded-full bg-emerald-100 text-emerald-800">${t}</span>`)
        .join("");
    }

    if (ingredientsContainer) {
      ingredientsContainer.innerHTML = recipe.ingredients
        .map(
          item => `
          <li class="flex items-center justify-between text-sm py-1.5 border-b border-slate-100 last:border-b-0">
            <span class="text-slate-700 flex items-center gap-2">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              ${item.name}
            </span>
            <span class="font-medium text-slate-500 text-xs bg-slate-100 px-2 py-0.5 rounded-md">${item.amount} ${item.unit}</span>
          </li>
        `
        )
        .join("");
    }

    if (instructionsContainer) {
      instructionsContainer.innerHTML = recipe.instructions
        .map(
          (step, idx) => `
          <li class="flex items-start gap-3 text-sm text-slate-700">
            <span class="shrink-0 w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 font-bold text-xs flex items-center justify-center mt-0.5">
              ${idx + 1}
            </span>
            <span class="leading-relaxed">${step}</span>
          </li>
        `
        )
        .join("");
    }

    modal?.classList.remove("hidden");
    modal?.classList.add("flex");
    if (window.lucide) window.lucide.createIcons();
  }

  closeRecipeDetail() {
    const modal = document.getElementById("recipe-detail-modal");
    modal?.classList.add("hidden");
    modal?.classList.remove("flex");
  }

  // Render Tampilan Hari yang Aktif
  renderDayView() {
    const dayData = this.getActiveDayData();
    const currentUser = authManager.getUser();
    const userTargetCalories = currentUser?.healthProfile?.targetCalories || 1600;

    // Update Tab Hari
    this.renderDayTabs();

    // Hitung Total Nutrisi Hari Ini
    const slotKeys = ["breakfast", "lunch", "dinner", "snack"];
    let dayTotalCalories = 0;
    let dayTotalProtein = 0;
    let dayTotalCarbs = 0;
    let dayTotalFat = 0;
    let consumedCalories = 0;

    slotKeys.forEach(slot => {
      const recId = dayData.meals[slot];
      const rec = RECIPE_MAP[recId];
      if (rec) {
        dayTotalCalories += rec.calories;
        dayTotalProtein += rec.protein;
        dayTotalCarbs += rec.carbs;
        dayTotalFat += rec.fat;
        if (dayData.consumed && dayData.consumed[slot]) {
          consumedCalories += rec.calories;
        }
      }
    });

    // Perbarui Widget Ringkasan Kalori Harian
    const dayNameTitle = document.getElementById("current-day-name");
    const dayCaloriesTarget = document.getElementById("day-calories-target");
    const dayCaloriesPlanned = document.getElementById("day-calories-planned");
    const dayCaloriesConsumed = document.getElementById("day-calories-consumed");
    const calorieProgressBar = document.getElementById("calorie-progress-bar");
    const macroProtein = document.getElementById("day-macro-protein");
    const macroCarbs = document.getElementById("day-macro-carbs");
    const macroFat = document.getElementById("day-macro-fat");

    if (dayNameTitle) {
      dayNameTitle.textContent = `${dayData.dayName} (${dayData.dateLabel || "Hari ke-" + this.selectedDay})`;
    }
    if (dayCaloriesTarget) dayCaloriesTarget.textContent = `${userTargetCalories} kcal`;
    if (dayCaloriesPlanned) dayCaloriesPlanned.textContent = `${dayTotalCalories} kcal`;
    if (dayCaloriesConsumed) dayCaloriesConsumed.textContent = `${consumedCalories} kcal`;

    if (calorieProgressBar) {
      const pct = Math.min(100, Math.round((consumedCalories / userTargetCalories) * 100));
      calorieProgressBar.style.width = `${pct}%`;
    }

    if (macroProtein) macroProtein.textContent = `${dayTotalProtein}g`;
    if (macroCarbs) macroCarbs.textContent = `${dayTotalCarbs}g`;
    if (macroFat) macroFat.textContent = `${dayTotalFat}g`;

    // Render 4 Kartu Slot Makanan
    const container = document.getElementById("meal-slots-container");
    if (!container) return;

    const slotMetadata = {
      breakfast: { label: "Sarapan Pagi", icon: "sunrise", time: "07:00 - 08:30", bg: "bg-amber-50 text-amber-700 border-amber-200" },
      lunch: { label: "Makan Siang", icon: "sun", time: "12:00 - 13:30", bg: "bg-emerald-50 text-emerald-700 border-emerald-200" },
      dinner: { label: "Makan Malam", icon: "moon", time: "18:30 - 20:00", bg: "bg-indigo-50 text-indigo-700 border-indigo-200" },
      snack: { label: "Camilan Sehat", icon: "apple", time: "15:30 - 16:30", bg: "bg-teal-50 text-teal-700 border-teal-200" }
    };

    container.innerHTML = slotKeys
      .map(slot => {
        const meta = slotMetadata[slot];
        const recipeId = dayData.meals[slot];
        const recipe = RECIPE_MAP[recipeId] || RECIPES_DATA[0];
        const isConsumed = !!(dayData.consumed && dayData.consumed[slot]);

        return `
          <div class="bg-white rounded-2xl border transition-all duration-300 overflow-hidden ${
            isConsumed
              ? "border-emerald-400 bg-emerald-50/20 shadow-sm"
              : "border-slate-100 hover:border-emerald-200 hover:shadow-lg shadow-sm"
          }">
            <!-- Header Slot -->
            <div class="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between bg-slate-50/60">
              <div class="flex items-center gap-2.5">
                <span class="w-8 h-8 rounded-xl ${meta.bg} flex items-center justify-center font-bold text-sm shadow-xs border">
                  <i data-lucide="${meta.icon}" class="w-4 h-4"></i>
                </span>
                <div>
                  <h3 class="font-bold text-slate-800 text-sm">${meta.label}</h3>
                  <span class="text-[11px] text-slate-600">${meta.time}</span>
                </div>
              </div>

              <!-- Tombol Status Selesai / Checklist -->
              <button 
                onclick="mealPlanner.toggleConsumed('${slot}')"
                class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  isConsumed
                    ? "bg-emerald-600 text-white shadow-sm"
                    : "bg-slate-100 hover:bg-emerald-100 text-slate-600 hover:text-emerald-800"
                }">
                <i data-lucide="${isConsumed ? "check-circle-2" : "circle"}" class="w-4 h-4"></i>
                <span>${isConsumed ? "Sudah Dimakan" : "Tandai Dimakan"}</span>
              </button>
            </div>

            <!-- Body Kartu Makanan -->
            <div class="p-5 flex flex-col sm:flex-row gap-5 items-start">
              <div class="relative w-full sm:w-36 h-36 rounded-xl overflow-hidden shrink-0 group">
                <img src="${recipe.image}" alt="${recipe.name}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                <span class="absolute bottom-2 left-2 bg-black/60 backdrop-blur-md text-white text-[11px] px-2 py-0.5 rounded-lg flex items-center gap-1 font-medium">
                  <i data-lucide="clock" class="w-3 h-3"></i> ${recipe.cookTime}
                </span>
              </div>

              <div class="flex-1 min-w-0 flex flex-col justify-between h-full w-full">
                <div>
                  <div class="flex items-center gap-1.5 flex-wrap mb-2">
                    ${recipe.tags
                      .map(
                        t => `<span class="px-2 py-0.5 text-[11px] font-medium rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">${t}</span>`
                      )
                      .join("")}
                  </div>
                  <h4 class="font-bold text-slate-800 text-lg hover:text-emerald-600 cursor-pointer transition-colors" onclick="mealPlanner.openRecipeDetail('${recipe.id}')">
                    ${recipe.name}
                  </h4>
                  <p class="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                    ${recipe.description}
                  </p>
                </div>

                <!-- Nutrisi Makro Bar -->
                <div class="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between flex-wrap gap-2">
                  <div class="flex items-center gap-3 text-xs">
                    <span class="font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-100">
                      ${recipe.calories} kcal
                    </span>
                    <span class="text-slate-500 font-medium">P: <strong class="text-slate-700">${recipe.protein}g</strong></span>
                    <span class="text-slate-500 font-medium">K: <strong class="text-slate-700">${recipe.carbs}g</strong></span>
                    <span class="text-slate-500 font-medium">L: <strong class="text-slate-700">${recipe.fat}g</strong></span>
                  </div>

                  <!-- Aksi: Detail Resep & Ganti Menu -->
                  <div class="flex items-center gap-2">
                    <button 
                      onclick="mealPlanner.openRecipeDetail('${recipe.id}')"
                      class="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors flex items-center gap-1">
                      <i data-lucide="book-open" class="w-3.5 h-3.5"></i> Resep
                    </button>
                    <button 
                      onclick="mealPlanner.openSwapModal('${slot}')"
                      class="px-3 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-100 hover:bg-emerald-200 rounded-xl transition-colors flex items-center gap-1">
                      <i data-lucide="refresh-cw" class="w-3.5 h-3.5"></i> Ganti
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        `;
      })
      .join("");

    if (window.lucide) window.lucide.createIcons();
  }

  // Render Bar Navigasi Hari (Senin - Minggu)
  renderDayTabs() {
    const tabsContainer = document.getElementById("day-tabs-container");
    if (!tabsContainer) return;

    const days = [
      { num: 1, name: "Senin", short: "Sen" },
      { num: 2, name: "Selasa", short: "Sel" },
      { num: 3, name: "Rabu", short: "Rab" },
      { num: 4, name: "Kamis", short: "Kam" },
      { num: 5, name: "Jumat", short: "Jum" },
      { num: 6, name: "Sabtu", short: "Sab" },
      { num: 7, name: "Minggu", short: "Min" }
    ];

    tabsContainer.innerHTML = days
      .map(d => {
        const isActive = this.selectedDay === d.num;
        // Ambil data hari untuk cek persentase selesai
        const dayData = this.currentMode === "weekly" ? this.weeklyPlan[d.num] : this.monthlyPlan[this.selectedWeek][d.num];
        const isComplete = dayData?.consumed && ["breakfast", "lunch", "dinner", "snack"].every(s => dayData.consumed[s]);

        return `
          <button 
            onclick="mealPlanner.setSelectedDay(${d.num})"
            class="flex-1 min-w-[70px] py-2.5 px-2 rounded-2xl flex flex-col items-center justify-center transition-all ${
              isActive
                ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/20 scale-[1.02]"
                : "bg-white hover:bg-emerald-50/60 text-slate-700 border border-slate-200/80"
            }">
            <span class="text-xs font-semibold ${isActive ? "text-emerald-100" : "text-slate-600"}">${d.short}</span>
            <span class="text-sm font-bold mt-0.5">${d.name}</span>
            ${
              isComplete
                ? `<span class="mt-1 w-2 h-2 rounded-full ${isActive ? "bg-white" : "bg-emerald-500"}"></span>`
                : ""
            }
          </button>
        `;
      })
      .join("");
  }

  // Render Ikhtisar Kalender Bulanan (4 Pekan)
  renderMonthOverview() {
    const container = document.getElementById("month-calendar-grid");
    if (!container) return;

    const weeks = [
      { id: "week1", title: "Pekan 1" },
      { id: "week2", title: "Pekan 2" },
      { id: "week3", title: "Pekan 3" },
      { id: "week4", title: "Pekan 4" }
    ];

    container.innerHTML = weeks
      .map(w => {
        const isCurrentWeek = this.selectedWeek === w.id;
        const weekData = this.monthlyPlan[w.id];

        // Hitung rata-rata kalori pekan
        let totalCal = 0;
        let dayCount = 0;
        for (let d = 1; d <= 7; d++) {
          const meals = weekData[d]?.meals || {};
          Object.values(meals).forEach(rid => {
            if (RECIPE_MAP[rid]) totalCal += RECIPE_MAP[rid].calories;
          });
          dayCount++;
        }
        const avgCal = Math.round(totalCal / dayCount);

        return `
          <div 
            onclick="mealPlanner.setSelectedWeek('${w.id}')"
            class="p-4 rounded-2xl border cursor-pointer transition-all ${
              isCurrentWeek
                ? "border-emerald-500 bg-emerald-50/40 ring-2 ring-emerald-500/30 shadow-sm"
                : "border-slate-200 hover:border-emerald-300 bg-white"
            }">
            <div class="flex items-center justify-between mb-2">
              <h4 class="font-bold text-slate-800 text-sm">${w.title}</h4>
              <span class="text-xs px-2 py-0.5 rounded-full ${isCurrentWeek ? "bg-emerald-600 text-white" : "bg-slate-100 text-slate-600"}">
                ${isCurrentWeek ? "Aktif" : "Pilih"}
              </span>
            </div>
            <p class="text-xs text-slate-500">Rata-rata kalori: <strong class="text-emerald-700">${avgCal} kcal/hari</strong></p>
            <div class="grid grid-cols-7 gap-1 mt-3">
              ${[1, 2, 3, 4, 5, 6, 7]
                .map(d => {
                  return `<div class="h-6 rounded-md bg-emerald-100/70 text-[10px] font-bold text-emerald-800 flex items-center justify-center">H${d}</div>`;
                })
                .join("")}
            </div>
          </div>
        `;
      })
      .join("");
  }
}

const mealPlanner = new MealPlanner();
