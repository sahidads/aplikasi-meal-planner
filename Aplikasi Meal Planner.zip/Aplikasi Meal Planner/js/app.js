/**
 * NutriPlan Green - Aplikasi Utama (Main Application Controller)
 * Menghubungkan navigasi tab, event listener, modal autentikasi, kalkulator, dan katalog resep.
 */

// Sistem Notifikasi Toast Interaktif
function showToast(message, type = "info") {
  const container = document.getElementById("toast-container");
  if (!container) return;

  const toast = document.createElement("div");
  const bgColors = {
    info: "bg-slate-800 text-white",
    success: "bg-emerald-600 text-white shadow-emerald-600/30",
    warning: "bg-amber-500 text-white shadow-amber-500/30",
    error: "bg-rose-600 text-white shadow-rose-600/30"
  };

  const icons = {
    info: "info",
    success: "check-circle",
    warning: "alert-triangle",
    error: "alert-circle"
  };

  toast.className = `flex items-center gap-2.5 px-4 py-3 rounded-2xl shadow-lg text-sm font-medium transition-all duration-300 transform translate-y-3 opacity-0 ${
    bgColors[type] || bgColors.info
  }`;

  toast.innerHTML = `
    <i data-lucide="${icons[type] || "info"}" class="w-4 h-4 shrink-0"></i>
    <span class="flex-1">${message}</span>
  `;

  container.appendChild(toast);
  if (window.lucide) window.lucide.createIcons();

  // Animasi muncul
  requestAnimationFrame(() => {
    toast.classList.remove("translate-y-3", "opacity-0");
  });

  // Hapus setelah 3.5 detik
  setTimeout(() => {
    toast.classList.add("opacity-0", "translate-y-2");
    setTimeout(() => {
      container.removeChild(toast);
    }, 300);
  }, 3500);
}

class AppController {
  constructor() {
    this.activeTab = "planner"; // 'planner' | 'calculator' | 'grocery' | 'recipes' | 'profile'
    this.activeCatalogCategory = "all";
    this.catalogSearchQuery = "";
  }

  async init() {
    // Inisialisasi koneksi Supabase Service terlebih dahulu
    if (typeof supabaseService !== "undefined") {
      await supabaseService.init();
    }

    // Periksa status auth awal (termasuk session cloud Supabase)
    if (typeof authManager !== "undefined") {
      await authManager.loadSession();
    }

    this.bindNavigation();
    this.bindAuthEvents();
    this.bindCalculatorEvents();
    this.bindGroceryEvents();
    this.bindRecipeCatalogEvents();
    this.listenToAuthChanges();

    // Periksa apakah user membuka link reset password dari email Supabase
    const isRecovery = this.checkRecoveryHash();

    // Auth Guard: Jika belum login, tampilkan halaman Login. Jika sudah login, buka Dashboard
    if (!isRecovery) {
      if (authManager.isLoggedIn()) {
        this.showDashboard();
      } else {
        this.showAuthScreen("login");
      }
    }

    // Render inisial
    this.switchTab(this.activeTab);
    mealPlanner.renderDayView();
    groceryManager.renderGroceryList();
    this.renderRecipeCatalog();
    this.populateCalculatorFromUser();

    if (window.lucide) window.lucide.createIcons();
  }

  // Tampilkan Layar Autentikasi (login | register | forgot | reset)
  showAuthScreen(subView = "login") {
    const authScreen = document.getElementById("auth-screen");
    const dashboardView = document.getElementById("dashboard-view");
    const alertBox = document.getElementById("auth-alert");

    if (authScreen) authScreen.classList.remove("hidden");
    if (dashboardView) dashboardView.classList.add("hidden");
    if (alertBox) alertBox.classList.add("hidden");

    ["login", "register", "forgot", "reset"].forEach(v => {
      const el = document.getElementById(`auth-view-${v}`);
      if (el) el.classList.add("hidden");
    });

    const target = document.getElementById(`auth-view-${subView}`);
    if (target) {
      target.classList.remove("hidden");
      target.classList.add("animate-fade-in");
    }

    window.scrollTo({ top: 0, behavior: "smooth" });
    if (window.lucide) window.lucide.createIcons();
  }

  // Tampilkan Dashboard Aplikasi GREEN DIET
  showDashboard() {
    const authScreen = document.getElementById("auth-screen");
    const dashboardView = document.getElementById("dashboard-view");

    if (authScreen) authScreen.classList.add("hidden");
    if (dashboardView) dashboardView.classList.remove("hidden");

    const user = authManager.getUser();
    this.updateAuthUI(user);
    this.populateCalculatorFromUser();
    mealPlanner.renderDayView();
    groceryManager.renderGroceryList();

    window.scrollTo({ top: 0, behavior: "smooth" });
    if (window.lucide) window.lucide.createIcons();
  }

  // Tampilkan Notifikasi Pesan di Form Autentikasi
  showAuthAlert(message, type = "error") {
    const alertBox = document.getElementById("auth-alert");
    if (!alertBox) return;

    if (type === "success") {
      alertBox.className = "p-4 rounded-2xl text-xs font-semibold mb-6 flex items-start gap-3 bg-emerald-50 text-emerald-800 border border-emerald-200 animate-fade-in";
      alertBox.innerHTML = `
        <i data-lucide="check-circle-2" class="w-4 h-4 text-emerald-600 shrink-0 mt-0.5"></i>
        <div class="leading-relaxed flex-1">${message}</div>
      `;
    } else {
      alertBox.className = "p-4 rounded-2xl text-xs font-semibold mb-6 flex items-start gap-3 bg-rose-50 text-rose-700 border border-rose-200 animate-fade-in";
      alertBox.innerHTML = `
        <i data-lucide="alert-circle" class="w-4 h-4 text-rose-600 shrink-0 mt-0.5"></i>
        <div class="leading-relaxed flex-1">${message}</div>
      `;
    }
    alertBox.classList.remove("hidden");
    if (window.lucide) window.lucide.createIcons();
    alertBox.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  // Toggle Lihat / Sembunyikan Password
  togglePasswordVisibility(inputId, btn) {
    const input = document.getElementById(inputId);
    if (!input) return;

    if (input.type === "password") {
      input.type = "text";
      btn.innerHTML = `<i data-lucide="eye-off" class="w-4 h-4"></i>`;
    } else {
      input.type = "password";
      btn.innerHTML = `<i data-lucide="eye" class="w-4 h-4"></i>`;
    }
    if (window.lucide) window.lucide.createIcons();
  }

  // Handler Logout dari Dashboard
  async handleLogout() {
    if (confirm("Apakah Anda yakin ingin keluar dari akun GREEN DIET?")) {
      await authManager.logout();
      this.showAuthScreen("login");
      showToast("Anda telah berhasil keluar dari akun.", "info");
    }
  }

  // Handler Masuk Cepat Akun Demo
  async handleQuickDemoLogin() {
    const res = await authManager.login("demo@greendiet.id", "password123");
    if (res.success) {
      this.showDashboard();
      showToast("Masuk dalam mode demo Sarah Wijaya!", "success");
    } else {
      authManager.loginAsGuest();
      this.showDashboard();
      showToast("Masuk dalam mode tamu.", "info");
    }
  }

  // Deteksi token recovery reset password dari email
  checkRecoveryHash() {
    if (window.location.hash && window.location.hash.includes("type=recovery")) {
      this.showAuthScreen("reset");
      this.showAuthAlert("Silakan tentukan kata sandi baru untuk akun GREEN DIET Anda di bawah ini.", "success");
      return true;
    }
    return false;
  }

  // Navigasi Tab Utama (Desktop & Mobile)
  bindNavigation() {
    const navButtons = document.querySelectorAll("[data-nav-target]");
    navButtons.forEach(btn => {
      btn.addEventListener("click", e => {
        e.preventDefault();
        const target = btn.getAttribute("data-nav-target");
        this.switchTab(target);
      });
    });
  }

  switchTab(tabId) {
    this.activeTab = tabId;

    // Sembunyikan semua tab content
    const sections = document.querySelectorAll(".tab-content-section");
    sections.forEach(sec => sec.classList.add("hidden"));

    // Tampilkan tab yang dipilih
    const activeSection = document.getElementById(`section-${tabId}`);
    if (activeSection) {
      activeSection.classList.remove("hidden");
      activeSection.classList.add("animate-fade-in");
    }

    // Perbarui status aktif tombol navigasi desktop & mobile
    const navButtons = document.querySelectorAll("[data-nav-target]");
    navButtons.forEach(btn => {
      const target = btn.getAttribute("data-nav-target");
      const isMobile = btn.closest("#bottom-nav");

      if (target === tabId) {
        if (isMobile) {
          btn.classList.add("text-emerald-600", "scale-105");
          btn.classList.remove("text-slate-600");
          const iconSpan = btn.querySelector("span:first-child");
          iconSpan?.classList.add("bg-emerald-100", "text-emerald-700");
        } else {
          btn.classList.add("text-emerald-700", "bg-emerald-50", "font-bold");
          btn.classList.remove("text-slate-600", "hover:bg-slate-100");
        }
      } else {
        if (isMobile) {
          btn.classList.remove("text-emerald-600", "scale-105");
          btn.classList.add("text-slate-600");
          const iconSpan = btn.querySelector("span:first-child");
          iconSpan?.classList.remove("bg-emerald-100", "text-emerald-700");
        } else {
          btn.classList.remove("text-emerald-700", "bg-emerald-50", "font-bold");
          btn.classList.add("text-slate-600", "hover:bg-slate-100");
        }
      }
    });

    // Refresh konten spesifik jika diperlukan
    if (tabId === "planner") {
      mealPlanner.renderDayView();
    } else if (tabId === "grocery") {
      groceryManager.renderGroceryList();
    } else if (tabId === "recipes") {
      this.renderRecipeCatalog();
    } else if (tabId === "profile") {
      this.renderProfileView();
    }

    // Scroll ke atas dengan halus
    window.scrollTo({ top: 0, behavior: "smooth" });
    if (window.lucide) window.lucide.createIcons();
  }

  // Sinkronisasi status autentikasi member
  listenToAuthChanges() {
    const handleAuthEvent = e => {
      const user = e.detail;
      if (user) {
        this.updateAuthUI(user);
        this.populateCalculatorFromUser();
        mealPlanner.renderDayView();
        this.renderProfileView();
      } else {
        // Jika logout, pastikan beralih ke halaman login
        this.showAuthScreen("login");
      }
    };

    window.addEventListener("greendiet_auth_changed", handleAuthEvent);
    window.addEventListener("nutriplan_auth_changed", handleAuthEvent);

    // Panggil sekali untuk status awal
    this.updateAuthUI(authManager.getUser());
  }

  updateAuthUI(user) {
    const userBadgeBtn = document.getElementById("header-user-badge");
    const userAvatarImg = document.getElementById("header-user-avatar");
    const userNameLabel = document.getElementById("header-user-name");
    const userGoalBadge = document.getElementById("header-user-goal");

    if (user) {
      if (userNameLabel) userNameLabel.textContent = user.name;
      if (userAvatarImg) userAvatarImg.src = user.avatar;
      if (userGoalBadge) {
        const cal = user.healthProfile?.targetCalories || 1600;
        const cloudBadge = user.isCloudUser ? " (Cloud)" : "";
        userGoalBadge.textContent = `${cal} kcal/hari${cloudBadge}`;
      }
    }
  }

  // Modul Interaksi Autentikasi (Halaman Login, Registrasi, & Lupa Password)
  bindAuthEvents() {
    // ===== 1. FORM HALAMAN AUTENTIKASI UTAMA =====
    const formAuthLogin = document.getElementById("auth-login-form");
    const formAuthRegister = document.getElementById("auth-register-form");
    const formAuthForgot = document.getElementById("auth-forgot-form");
    const formAuthReset = document.getElementById("auth-reset-form");

    // Submit Login Halaman Utama
    formAuthLogin?.addEventListener("submit", async e => {
      e.preventDefault();
      const email = document.getElementById("auth-login-email")?.value;
      const pass = document.getElementById("auth-login-password")?.value;
      const btn = document.getElementById("btn-login-submit");

      if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<span class="animate-spin inline-block mr-2">&#9696;</span> Memproses Masuk...`;
      }

      const res = await authManager.login(email, pass);

      if (btn) {
        btn.disabled = false;
        btn.innerHTML = `<i data-lucide="log-in" class="w-4 h-4"></i><span>Masuk ke Dashboard GREEN DIET</span>`;
        if (window.lucide) window.lucide.createIcons();
      }

      if (res.success) {
        this.showAuthAlert(res.message, "success");
        setTimeout(() => {
          this.showDashboard();
          showToast(`Selamat datang kembali, ${authManager.getUser()?.name}!`, "success");
        }, 350);
      } else {
        this.showAuthAlert(res.message, "error");
      }
    });

    // Submit Registrasi Halaman Utama
    formAuthRegister?.addEventListener("submit", async e => {
      e.preventDefault();
      const name = document.getElementById("auth-register-name")?.value;
      const email = document.getElementById("auth-register-email")?.value;
      const pass = document.getElementById("auth-register-password")?.value;
      const confirmPass = document.getElementById("auth-register-confirm-password")?.value;
      const btn = document.getElementById("btn-register-submit");

      if (pass !== confirmPass) {
        this.showAuthAlert("Kata sandi dan konfirmasi kata sandi tidak cocok. Harap periksa kembali.", "error");
        return;
      }

      if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<span class="animate-spin inline-block mr-2">&#9696;</span> Mendaftarkan Akun...`;
      }

      const res = await authManager.register(name, email, pass, confirmPass);

      if (btn) {
        btn.disabled = false;
        btn.innerHTML = `<i data-lucide="user-plus" class="w-4 h-4"></i><span>Daftar Akun Member GREEN DIET</span>`;
        if (window.lucide) window.lucide.createIcons();
      }

      if (res.success) {
        this.showAuthAlert(res.message, "success");
        if (res.user && res.user.id) {
          setTimeout(() => {
            this.showDashboard();
            showToast(`Selamat bergabung di GREEN DIET, ${res.user.name}! 🎉`, "success");
          }, 600);
        }
      } else {
        this.showAuthAlert(res.message, "error");
      }
    });

    // Submit Lupa Password Halaman Utama
    formAuthForgot?.addEventListener("submit", async e => {
      e.preventDefault();
      const email = document.getElementById("auth-forgot-email")?.value;
      const btn = document.getElementById("btn-forgot-submit");

      if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<span class="animate-spin inline-block mr-2">&#9696;</span> Mengirim Tautan...`;
      }

      const res = await authManager.resetPassword(email);

      if (btn) {
        btn.disabled = false;
        btn.innerHTML = `<i data-lucide="send" class="w-4 h-4"></i><span>Kirim Link Reset Kata Sandi</span>`;
        if (window.lucide) window.lucide.createIcons();
      }

      if (res.success) {
        this.showAuthAlert(res.message, "success");
      } else {
        this.showAuthAlert(res.message, "error");
      }
    });

    // Submit Reset Password Baru (dari Tautan Recovery)
    formAuthReset?.addEventListener("submit", async e => {
      e.preventDefault();
      const pass = document.getElementById("auth-reset-password")?.value;
      const confirmPass = document.getElementById("auth-reset-confirm-password")?.value;
      const btn = document.getElementById("btn-reset-submit");

      if (pass !== confirmPass) {
        this.showAuthAlert("Kata sandi baru dan konfirmasi kata sandi tidak cocok.", "error");
        return;
      }

      if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<span class="animate-spin inline-block mr-2">&#9696;</span> Menyimpan Sandi Baru...`;
      }

      const res = await authManager.updatePassword(pass);

      if (btn) {
        btn.disabled = false;
        btn.innerHTML = `<i data-lucide="check" class="w-4 h-4"></i><span>Simpan Kata Sandi Baru & Masuk</span>`;
        if (window.lucide) window.lucide.createIcons();
      }

      if (res.success) {
        this.showAuthAlert("Kata sandi berhasil diperbarui! Mengalihkan ke halaman masuk...", "success");
        setTimeout(() => {
          window.location.hash = "";
          this.showAuthScreen("login");
        }, 1500);
      } else {
        this.showAuthAlert(res.message, "error");
      }
    });

    // ===== 2. MODAL AUTH KOMPATIBILITAS (JIKA DIAKSES DARI MODAL) =====
    const authModal = document.getElementById("auth-modal");
    const openAuthBtn = document.getElementById("header-user-badge");
    const closeAuthBtn = document.getElementById("btn-close-auth-modal");
    const tabLoginBtn = document.getElementById("auth-tab-login");
    const tabRegisterBtn = document.getElementById("auth-tab-register");
    const tabForgotBtn = document.getElementById("auth-tab-forgot");

    const formLogin = document.getElementById("form-login");
    const formRegister = document.getElementById("form-register");
    const formForgot = document.getElementById("form-forgot");
    const formNewPass = document.getElementById("form-new-password");

    const btnDemoLogin = document.getElementById("btn-quick-demo-login");
    const btnGuestLogin = document.getElementById("btn-guest-mode");

    closeAuthBtn?.addEventListener("click", () => {
      authModal?.classList.add("hidden");
      authModal?.classList.remove("flex");
    });

    const resetTabs = () => {
      [tabLoginBtn, tabRegisterBtn, tabForgotBtn].forEach(b => {
        b?.classList.remove("text-emerald-700", "border-b-2", "border-emerald-600", "font-bold");
        b?.classList.add("text-slate-500");
      });
      [formLogin, formRegister, formForgot, formNewPass].forEach(f => f?.classList.add("hidden"));
    };

    tabLoginBtn?.addEventListener("click", () => {
      resetTabs();
      tabLoginBtn.classList.add("text-emerald-700", "border-b-2", "border-emerald-600", "font-bold");
      tabLoginBtn.classList.remove("text-slate-500");
      formLogin?.classList.remove("hidden");
    });

    tabRegisterBtn?.addEventListener("click", () => {
      resetTabs();
      tabRegisterBtn.classList.add("text-emerald-700", "border-b-2", "border-emerald-600", "font-bold");
      tabRegisterBtn.classList.remove("text-slate-500");
      formRegister?.classList.remove("hidden");
    });

    tabForgotBtn?.addEventListener("click", () => {
      resetTabs();
      tabForgotBtn.classList.add("text-emerald-700", "border-b-2", "border-emerald-600", "font-bold");
      tabForgotBtn.classList.remove("text-slate-500");
      formForgot?.classList.remove("hidden");
    });

    formLogin?.addEventListener("submit", async e => {
      e.preventDefault();
      const email = document.getElementById("login-email")?.value;
      const pass = document.getElementById("login-password")?.value;
      const res = await authManager.login(email, pass);
      if (res.success) {
        showToast(res.message, "success");
        authModal?.classList.add("hidden");
        authModal?.classList.remove("flex");
        this.showDashboard();
      } else {
        showToast(res.message, "error");
      }
    });

    formRegister?.addEventListener("submit", async e => {
      e.preventDefault();
      const name = document.getElementById("reg-name")?.value;
      const email = document.getElementById("reg-email")?.value;
      const pass = document.getElementById("reg-password")?.value;
      const res = await authManager.register(name, email, pass);
      if (res.success) {
        showToast(res.message, "success");
        authModal?.classList.add("hidden");
        authModal?.classList.remove("flex");
        if (res.user) this.showDashboard();
      } else {
        showToast(res.message, "error");
      }
    });

    btnDemoLogin?.addEventListener("click", () => {
      this.handleQuickDemoLogin();
      authModal?.classList.add("hidden");
      authModal?.classList.remove("flex");
    });

    btnGuestLogin?.addEventListener("click", () => {
      authManager.loginAsGuest();
      showToast("Menjelajah dalam mode tamu.", "info");
      authModal?.classList.add("hidden");
      authModal?.classList.remove("flex");
      this.showDashboard();
    });
  }

  // Modul Interaksi Kalkulator Kebutuhan Kalori
  bindCalculatorEvents() {
    const calcForm = document.getElementById("calorie-calc-form");
    const btnApplyToPlan = document.getElementById("btn-apply-calc-to-profile");

    calcForm?.addEventListener("submit", e => {
      e.preventDefault();
      this.executeCalorieCalculation();
    });

    // Realtime update saat nilai input berubah
    const calcInputs = calcForm?.querySelectorAll("input, select");
    calcInputs?.forEach(input => {
      input.addEventListener("change", () => {
        this.executeCalorieCalculation();
      });
    });

    btnApplyToPlan?.addEventListener("click", () => {
      const result = this.executeCalorieCalculation();
      if (result) {
        authManager.updateHealthProfile(result);
        showToast("Target kalori & makro berhasil diterapkan ke Profil dan Meal Planner! 🎯", "success");
        this.switchTab("planner");
      }
    });
  }

  // Isi data form kalkulator dari profil pengguna yang tersimpan
  populateCalculatorFromUser() {
    const user = authManager.getUser();
    if (!user || !user.healthProfile) return;
    const hp = user.healthProfile;

    const ageInput = document.getElementById("calc-age");
    const weightInput = document.getElementById("calc-weight");
    const heightInput = document.getElementById("calc-height");
    const genderSelect = document.getElementById("calc-gender");
    const activitySelect = document.getElementById("calc-activity");
    const goalSelect = document.getElementById("calc-goal");

    if (ageInput) ageInput.value = hp.age || 27;
    if (weightInput) weightInput.value = hp.weight || 62;
    if (heightInput) heightInput.value = hp.height || 165;
    if (genderSelect) genderSelect.value = hp.gender || "female";
    if (activitySelect) activitySelect.value = hp.activity || "moderate";
    if (goalSelect) goalSelect.value = hp.goal || "lose";

    this.executeCalorieCalculation();
  }

  // Jalankan kalkulasi BMR, TDEE, & Makro
  executeCalorieCalculation() {
    const age = parseInt(document.getElementById("calc-age")?.value, 10) || 27;
    const weight = parseFloat(document.getElementById("calc-weight")?.value) || 62;
    const height = parseFloat(document.getElementById("calc-height")?.value) || 165;
    const gender = document.getElementById("calc-gender")?.value || "female";
    const activity = document.getElementById("calc-activity")?.value || "moderate";
    const goal = document.getElementById("calc-goal")?.value || "lose";

    const res = calorieCalculator.computeFullProfile({ age, gender, weight, height, activity, goal });

    // Update UI hasil
    const elTarget = document.getElementById("calc-res-target");
    const elBmr = document.getElementById("calc-res-bmr");
    const elTdee = document.getElementById("calc-res-tdee");
    const elBmi = document.getElementById("calc-res-bmi");
    const elBmiBadge = document.getElementById("calc-res-bmi-badge");

    const elCarbs = document.getElementById("calc-res-carbs");
    const elProtein = document.getElementById("calc-res-protein");
    const elFat = document.getElementById("calc-res-fat");

    if (elTarget) elTarget.textContent = res.targetCalories;
    if (elBmr) elBmr.textContent = `${res.bmr} kcal`;
    if (elTdee) elTdee.textContent = `${res.tdee} kcal`;
    if (elBmi) elBmi.textContent = res.bmi;
    if (elBmiBadge) {
      elBmiBadge.textContent = res.bmiStatus;
      elBmiBadge.className = `px-3 py-1 rounded-full text-xs font-bold ${res.bmiBadge}`;
    }

    if (elCarbs) elCarbs.textContent = `${res.macros.carbs}g`;
    if (elProtein) elProtein.textContent = `${res.macros.protein}g`;
    if (elFat) elFat.textContent = `${res.macros.fat}g`;

    return res;
  }

  // Modul Interaksi Daftar Belanja
  bindGroceryEvents() {
    const btnAddCustom = document.getElementById("btn-add-custom-grocery");
    const formAddCustom = document.getElementById("form-add-custom-grocery");
    const modalCustom = document.getElementById("modal-add-custom-grocery");
    const btnCloseModal = document.getElementById("btn-close-custom-modal");
    const btnReset = document.getElementById("btn-reset-grocery");

    btnAddCustom?.addEventListener("click", () => {
      modalCustom?.classList.remove("hidden");
      modalCustom?.classList.add("flex");
    });

    btnCloseModal?.addEventListener("click", () => {
      modalCustom?.classList.add("hidden");
      modalCustom?.classList.remove("flex");
    });

    formAddCustom?.addEventListener("submit", e => {
      e.preventDefault();
      const name = document.getElementById("custom-item-name")?.value;
      const amount = document.getElementById("custom-item-amount")?.value;
      const category = document.getElementById("custom-item-category")?.value;
      groceryManager.addCustomItem(name, amount, category);
      modalCustom?.classList.add("hidden");
      modalCustom?.classList.remove("flex");
      formAddCustom.reset();
    });

    btnReset?.addEventListener("click", () => {
      if (confirm("Reset seluruh checklist belanjaan yang sudah dicentang?")) {
        groceryManager.resetChecklist();
      }
    });
  }

  // Modul Katalog Resep
  bindRecipeCatalogEvents() {
    const searchInput = document.getElementById("catalog-search-input");
    const catButtons = document.querySelectorAll("[data-recipe-cat]");

    searchInput?.addEventListener("input", e => {
      this.catalogSearchQuery = e.target.value.toLowerCase().trim();
      this.renderRecipeCatalog();
    });

    catButtons.forEach(btn => {
      btn.addEventListener("click", () => {
        catButtons.forEach(b => {
          b.classList.remove("bg-emerald-600", "text-white", "shadow-sm");
          b.classList.add("bg-white", "text-slate-600", "hover:bg-slate-100");
        });
        btn.classList.add("bg-emerald-600", "text-white", "shadow-sm");
        btn.classList.remove("bg-white", "text-slate-600", "hover:bg-slate-100");

        this.activeCatalogCategory = btn.getAttribute("data-recipe-cat");
        this.renderRecipeCatalog();
      });
    });
  }

  renderRecipeCatalog() {
    const container = document.getElementById("recipe-catalog-grid");
    if (!container) return;

    let recipes = RECIPES_DATA;

    if (this.activeCatalogCategory !== "all") {
      recipes = recipes.filter(r => r.category === this.activeCatalogCategory);
    }

    if (this.catalogSearchQuery) {
      recipes = recipes.filter(
        r =>
          r.name.toLowerCase().includes(this.catalogSearchQuery) ||
          r.description.toLowerCase().includes(this.catalogSearchQuery) ||
          r.tags.some(t => t.toLowerCase().includes(this.catalogSearchQuery)) ||
          r.ingredients.some(ing => ing.name.toLowerCase().includes(this.catalogSearchQuery))
      );
    }

    if (recipes.length === 0) {
      container.innerHTML = `
        <div class="col-span-full py-12 text-center text-slate-500">
          <i data-lucide="utensils" class="w-12 h-12 mx-auto text-slate-300 mb-2"></i>
          <p class="font-medium">Tidak ada resep diet yang cocok dengan pencarian "${this.catalogSearchQuery}".</p>
        </div>
      `;
      if (window.lucide) window.lucide.createIcons();
      return;
    }

    container.innerHTML = recipes
      .map(
        recipe => `
        <div class="bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-md hover:border-emerald-200 transition-all overflow-hidden flex flex-col group">
          <div class="relative h-44 overflow-hidden">
            <img src="${recipe.image}" alt="${recipe.name}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
            <span class="absolute top-3 left-3 bg-white/90 backdrop-blur-md px-2.5 py-1 rounded-full text-xs font-bold text-emerald-800 shadow-xs">
              ${recipe.calories} kcal
            </span>
            <span class="absolute bottom-3 right-3 bg-black/60 backdrop-blur-md text-white text-[11px] px-2 py-0.5 rounded-lg flex items-center gap-1 font-medium">
              <i data-lucide="clock" class="w-3 h-3"></i> ${recipe.cookTime}
            </span>
          </div>

          <div class="p-5 flex-1 flex flex-col justify-between">
            <div>
              <div class="flex items-center gap-1.5 flex-wrap mb-2">
                ${recipe.tags
                  .map(
                    t => `<span class="px-2 py-0.5 text-[11px] font-medium rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">${t}</span>`
                  )
                  .join("")}
              </div>
              <h4 class="font-bold text-slate-800 text-base group-hover:text-emerald-600 transition-colors cursor-pointer" onclick="mealPlanner.openRecipeDetail('${recipe.id}')">
                ${recipe.name}
              </h4>
              <p class="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">${recipe.description}</p>
            </div>

            <div class="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
              <div class="text-xs text-slate-500 flex items-center gap-2">
                <span>P: <strong>${recipe.protein}g</strong></span>
                <span>K: <strong>${recipe.carbs}g</strong></span>
                <span>L: <strong>${recipe.fat}g</strong></span>
              </div>
              <button 
                onclick="mealPlanner.openRecipeDetail('${recipe.id}')"
                class="px-3 py-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 text-xs font-bold rounded-xl transition-colors flex items-center gap-1">
                Resep <i data-lucide="arrow-right" class="w-3 h-3"></i>
              </button>
            </div>
          </div>
        </div>
      `
      )
      .join("");

    if (window.lucide) window.lucide.createIcons();
  }

  // Modul Tampilan Profil Member
  renderProfileView() {
    const user = authManager.getUser();
    if (!user) return;
    const hp = user.healthProfile || {};

    const nameEl = document.getElementById("profile-name");
    const emailEl = document.getElementById("profile-email");
    const avatarEl = document.getElementById("profile-avatar");
    const sinceEl = document.getElementById("profile-since");
    const targetCalEl = document.getElementById("profile-target-cal");
    const weightEl = document.getElementById("profile-weight");
    const heightEl = document.getElementById("profile-height");
    const bmiEl = document.getElementById("profile-bmi");

    if (nameEl) nameEl.textContent = user.name;
    if (emailEl) emailEl.textContent = user.email;
    if (avatarEl) avatarEl.src = user.avatar;
    if (sinceEl) sinceEl.textContent = user.memberSince || "Member Aktif";
    if (targetCalEl) targetCalEl.textContent = `${hp.targetCalories || 1600} kcal`;
    if (weightEl) weightEl.textContent = `${hp.weight || 62} kg`;
    if (heightEl) heightEl.textContent = `${hp.height || 165} cm`;
    if (bmiEl) bmiEl.textContent = hp.bmi || "22.8 (Ideal)";
  }
}

// Handler simpan kredensial Supabase manual dari modal bantuan
async function handleSaveManualSupabase() {
  const url = document.getElementById("manual-supabase-url")?.value;
  const key = document.getElementById("manual-supabase-anon")?.value;

  if (!url || !key) {
    showToast("Harap isi Project URL dan Anon Key dengan lengkap.", "warning");
    return;
  }

  if (typeof supabaseService !== "undefined") {
    await supabaseService.saveManualConfig(url, key);
    document.getElementById("modal-supabase-setup")?.classList.add("hidden");
    document.getElementById("modal-supabase-setup")?.classList.remove("flex");
    showToast("Kredensial Supabase berhasil disimpan! Cloud Database aktif.", "success");
  }
}

const app = new AppController();

document.addEventListener("DOMContentLoaded", () => {
  app.init();
});
