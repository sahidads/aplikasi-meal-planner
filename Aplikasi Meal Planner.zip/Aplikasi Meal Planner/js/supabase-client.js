/**
 * GREEN DIET - Supabase Client Bridge
 * Mengelola koneksi ke backend Supabase, autentikasi cloud, dan sinkronisasi database.
 */

class SupabaseService {
  constructor() {
    this.client = null;
    this.isConfigured = false;
    this.config = {
      url: "",
      anonKey: ""
    };
  }

  // Membersihkan format URL agar selalu mengarah ke root project Supabase
  cleanUrl(rawUrl) {
    if (!rawUrl) return "";
    let url = rawUrl.trim();
    // Hapus otomatis akhiran /rest/v1 atau /rest/v1/ jika pengguna tidak sengaja menyalinnya
    url = url.replace(/\/rest\/v1\/?$/i, "");
    // Hapus trailing slash
    url = url.replace(/\/+$/, "");
    return url;
  }

  // Inisialisasi koneksi dari file .env.local atau localStorage
  async init() {
    await this.loadCredentials();

    if (this.config.url && this.config.anonKey) {
      this.config.url = this.cleanUrl(this.config.url);
      if (window.supabase && typeof window.supabase.createClient === "function") {
        try {
          this.client = window.supabase.createClient(this.config.url, this.config.anonKey, {
            auth: {
              persistSession: true,
              autoRefreshToken: true,
              detectSessionInUrl: true
            }
          });
          this.isConfigured = true;
          console.log("✅ Supabase berhasil terhubung ke:", this.config.url);
        } catch (err) {
          console.error("Gagal inisialisasi Supabase client:", err);
          this.isConfigured = false;
        }
      } else {
        console.warn("Library @supabase/supabase-js belum termuat di browser.");
      }
    } else {
      console.log("ℹ️ Supabase belum dikonfigurasi. Masukkan kredensial di file .env.local.");
    }

    this.updateConfigBanner();
    return this.isConfigured;
  }

  // Membaca kredensial dari window.SUPABASE_CONFIG, .env.local, atau localStorage
  async loadCredentials() {
    // 0. Cek konfigurasi global jika ada
    if (window.SUPABASE_CONFIG && window.SUPABASE_CONFIG.url && window.SUPABASE_CONFIG.anonKey) {
      this.config.url = window.SUPABASE_CONFIG.url;
      this.config.anonKey = window.SUPABASE_CONFIG.anonKey;
      return;
    }

    // 1. Coba baca dari file .env.local via fetch jika sedang dijalankan di web server (http/https)
    if (window.location.protocol.startsWith("http")) {
      try {
        const response = await fetch(".env.local", { cache: "no-store" });
        if (response.ok) {
          const text = await response.text();
          const parsed = this.parseEnv(text);
          if (parsed.SUPABASE_URL && parsed.SUPABASE_ANON_KEY) {
            this.config.url = parsed.SUPABASE_URL;
            this.config.anonKey = parsed.SUPABASE_ANON_KEY;
            return;
          }
        }
      } catch (e) {
        // Abaikan jika fetch gagal
      }
    }

    // 2. Coba baca dari localStorage sebagai cadangan (jika file:// dibuka langsung)
    try {
      const cached = localStorage.getItem("greendiet_supabase_config");
      if (cached) {
        const parsedCache = JSON.parse(cached);
        if (parsedCache.url && parsedCache.anonKey) {
          this.config.url = parsedCache.url;
          this.config.anonKey = parsedCache.anonKey;
        }
      }
    } catch (e) {}
  }

  // Parser sederhana untuk file format .env
  parseEnv(content) {
    const lines = content.split("\n");
    const result = {};
    for (const line of lines) {
      const clean = line.trim();
      if (!clean || clean.startsWith("#")) continue;
      const eqIdx = clean.indexOf("=");
      if (eqIdx !== -1) {
        const key = clean.substring(0, eqIdx).trim();
        let val = clean.substring(eqIdx + 1).trim();
        // Hapus tanda kutip jika ada
        if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
          val = val.substring(1, val.length - 1);
        }
        result[key] = val;
      }
    }
    return result;
  }

  // Simpan kredensial secara manual jika pengguna memasukkannya lewat UI
  saveManualConfig(url, anonKey) {
    this.config.url = this.cleanUrl(url);
    this.config.anonKey = anonKey.trim();
    localStorage.setItem("greendiet_supabase_config", JSON.stringify(this.config));
    return this.init();
  }

  // Tampilkan banner status koneksi di bagian atas aplikasi
  updateConfigBanner() {
    const banner = document.getElementById("supabase-status-banner");
    if (!banner) return;

    if (!this.isConfigured) {
      banner.classList.remove("hidden");
    } else {
      banner.classList.add("hidden");
    }
  }

  // ================= METODE AUTENTIKASI =================

  // 1. Registrasi Akun Baru ke Supabase
  async register(email, password, fullName) {
    if (!this.isConfigured) {
      return { success: false, message: "Koneksi Supabase belum diatur di .env.local." };
    }

    try {
      const { data, error } = await this.client.auth.signUp({
        email: email.trim().toLowerCase(),
        password: password,
        options: {
          data: {
            full_name: fullName.trim()
          }
        }
      });

      if (error) throw error;

      // Jika email confirmation aktif, user mungkin belum langsung memiliki session aktif
      return {
        success: true,
        user: data.user,
        session: data.session,
        message: data.session
          ? "Pendaftaran berhasil! Selamat datang di GREEN DIET."
          : "Pendaftaran berhasil! Tautan konfirmasi telah dikirim ke email Anda. Silakan periksa inbox atau spam untuk mengaktifkan akun."
      };
    } catch (err) {
      let msg = "Gagal melakukan registrasi akun.";
      const raw = (err.message || "").toLowerCase();
      if (raw.includes("already registered") || raw.includes("user already exists") || raw.includes("email address is already in use")) {
        msg = "Alamat email ini sudah terdaftar. Silakan masuk (login) atau gunakan email lain.";
      } else if (raw.includes("password should be at least") || raw.includes("weak_password")) {
        msg = "Kata sandi terlalu pendek. Gunakan minimal 6 karakter.";
      } else if (raw.includes("valid email") || raw.includes("invalid email")) {
        msg = "Format alamat email tidak valid. Pastikan penulisan email benar (contoh: nama@gmail.com).";
      } else if (raw.includes("network") || raw.includes("fetch") || raw.includes("failed to fetch")) {
        msg = "Gagal terhubung ke server Supabase. Pastikan koneksi internet Anda aktif.";
      } else if (err.message) {
        msg = err.message;
      }
      return { success: false, message: msg };
    }
  }

  // 2. Login ke Supabase
  async login(email, password) {
    if (!this.isConfigured) {
      return { success: false, message: "Koneksi Supabase belum diatur di .env.local." };
    }

    try {
      const { data, error } = await this.client.auth.signInWithPassword({
        email: email.trim().toLowerCase(),
        password: password
      });

      if (error) throw error;

      return {
        success: true,
        user: data.user,
        session: data.session,
        message: "Login berhasil! Mengalihkan ke Dashboard..."
      };
    } catch (err) {
      let msg = "Email atau kata sandi tidak cocok. Silakan periksa kembali.";
      const raw = (err.message || "").toLowerCase();
      if (raw.includes("email not confirmed")) {
        msg = "Email Anda belum dikonfirmasi. Silakan buka email Anda dan klik tautan konfirmasi untuk mengaktifkan akun.";
      } else if (raw.includes("invalid login credentials") || raw.includes("invalid credentials")) {
        msg = "Email atau kata sandi tidak cocok. Silakan periksa kembali penulisan huruf besar/kecil.";
      } else if (raw.includes("too many requests") || raw.includes("rate limit")) {
        msg = "Terlalu banyak percobaan login yang gagal. Silakan tunggu 1-2 menit sebelum mencoba lagi.";
      } else if (raw.includes("network") || raw.includes("fetch") || raw.includes("failed to fetch")) {
        msg = "Gagal menghubungi server. Pastikan koneksi internet Anda aktif.";
      } else if (err.message) {
        msg = err.message;
      }
      return { success: false, message: msg };
    }
  }

  // 3. Logout dari Supabase
  async logout() {
    if (!this.isConfigured) return;
    try {
      await this.client.auth.signOut();
    } catch (e) {
      console.warn("Error saat logout Supabase:", e);
    }
  }

  // 4. Lupa Kata Sandi (Kirim Email Reset Password)
  async resetPassword(email) {
    if (!this.isConfigured) {
      return { success: false, message: "Koneksi Supabase belum diatur di .env.local." };
    }

    try {
      const redirectUrl = window.location.origin + window.location.pathname;
      const { error } = await this.client.auth.resetPasswordForEmail(email.trim().toLowerCase(), {
        redirectTo: redirectUrl
      });

      if (error) throw error;

      return {
        success: true,
        message: "Tautan reset kata sandi berhasil dikirim! Silakan periksa kotak masuk atau folder spam email Anda."
      };
    } catch (err) {
      let msg = "Gagal mengirim link reset password.";
      const raw = (err.message || "").toLowerCase();
      if (raw.includes("rate limit") || raw.includes("too many requests")) {
        msg = "Terlalu banyak permintaan reset dalam waktu singkat. Harap tunggu beberapa menit sebelum mencoba lagi.";
      } else if (raw.includes("user not found")) {
        msg = "Alamat email tidak terdaftar di sistem GREEN DIET.";
      } else if (err.message) {
        msg = err.message;
      }
      return { success: false, message: msg };
    }
  }

  // 5. Update Kata Sandi Baru
  async updatePassword(newPassword) {
    if (!this.isConfigured) return { success: false, message: "Supabase belum terhubung." };

    try {
      const { error } = await this.client.auth.updateUser({ password: newPassword });
      if (error) throw error;
      return { success: true, message: "Kata sandi baru berhasil disimpan! Silakan masuk kembali." };
    } catch (err) {
      let msg = "Gagal memperbarui kata sandi.";
      if (err.message && err.message.toLowerCase().includes("at least 6 characters")) {
        msg = "Kata sandi baru harus memiliki minimal 6 karakter.";
      } else if (err.message) {
        msg = err.message;
      }
      return { success: false, message: msg };
    }
  }

  // Ambil sesi user saat ini
  async getCurrentSession() {
    if (!this.isConfigured) return null;
    try {
      const { data } = await this.client.auth.getSession();
      return data.session;
    } catch (e) {
      return null;
    }
  }

  // ================= METODE DATABASE (ROW LEVEL SECURITY) =================

  // Ambil profil kesehatan member dari database Supabase
  async getProfile(userId) {
    if (!this.isConfigured || !userId) return null;
    try {
      const { data, error } = await this.client
        .from("profiles")
        .select("*")
        .eq("id", userId)
        .single();

      if (error && error.code !== "PGRST116") {
        console.warn("Gagal memuat profil Supabase:", error);
      }
      return data;
    } catch (e) {
      return null;
    }
  }

  // Simpan / Perbarui profil member di Supabase
  async upsertProfile(userId, profileData) {
    if (!this.isConfigured || !userId) return null;
    try {
      const payload = {
        id: userId,
        full_name: profileData.name || profileData.full_name,
        email: profileData.email,
        avatar_url: profileData.avatar || profileData.avatar_url,
        age: profileData.age,
        gender: profileData.gender,
        weight: profileData.weight,
        height: profileData.height,
        activity: profileData.activity,
        goal: profileData.goal,
        bmr: profileData.bmr,
        tdee: profileData.tdee,
        target_calories: profileData.targetCalories || profileData.target_calories,
        macros: profileData.macros,
        updated_at: new Date().toISOString()
      };

      const { data, error } = await this.client
        .from("profiles")
        .upsert(payload)
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (e) {
      console.error("Gagal menyimpan profil ke Supabase:", e);
      return null;
    }
  }

  // Ambil Meal Plan pribadi member dari database
  async getMealPlan(userId) {
    if (!this.isConfigured || !userId) return null;
    try {
      const { data, error } = await this.client
        .from("member_meal_plans")
        .select("*")
        .eq("user_id", userId)
        .single();

      if (error && error.code !== "PGRST116") {
        console.warn("Gagal mengambil meal plan dari Supabase:", error);
      }
      return data;
    } catch (e) {
      return null;
    }
  }

  // Simpan Meal Plan pribadi member ke database
  async saveMealPlan(userId, weeklyData, monthlyData, mode = "weekly") {
    if (!this.isConfigured || !userId) return null;
    try {
      const payload = {
        user_id: userId,
        plan_mode: mode,
        weekly_data: weeklyData,
        monthly_data: monthlyData,
        updated_at: new Date().toISOString()
      };

      const { data, error } = await this.client
        .from("member_meal_plans")
        .upsert(payload, { onConflict: "user_id" })
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (e) {
      console.error("Gagal menyimpan meal plan ke Supabase:", e);
      return null;
    }
  }

  // Ambil Daftar Belanja pribadi member dari database
  async getGroceries(userId) {
    if (!this.isConfigured || !userId) return null;
    try {
      const { data, error } = await this.client
        .from("member_groceries")
        .select("*")
        .eq("user_id", userId)
        .single();

      if (error && error.code !== "PGRST116") {
        console.warn("Gagal mengambil groceries dari Supabase:", error);
      }
      return data;
    } catch (e) {
      return null;
    }
  }

  // Simpan Daftar Belanja pribadi member ke database
  async saveGroceries(userId, checkedItemsArray, customItemsArray, scope = "week") {
    if (!this.isConfigured || !userId) return null;
    try {
      const payload = {
        user_id: userId,
        checked_items: checkedItemsArray,
        custom_items: customItemsArray,
        scope: scope,
        updated_at: new Date().toISOString()
      };

      const { data, error } = await this.client
        .from("member_groceries")
        .upsert(payload, { onConflict: "user_id" })
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (e) {
      console.error("Gagal menyimpan groceries ke Supabase:", e);
      return null;
    }
  }
}

const supabaseService = new SupabaseService();
