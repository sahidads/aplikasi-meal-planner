/**
 * GREEN DIET - Modul Autentikasi & Manajemen Sesi Member
 * Terintegrasi penuh dengan Supabase Auth & fallback lokal jika belum dikonfigurasi.
 */

const AUTH_STORAGE_KEY = "greendiet_current_user";
const USERS_DB_KEY = "greendiet_registered_users";

// Data Pengguna Contoh (Default Demo User)
const DEFAULT_DEMO_USER = {
  id: "user_demo_01",
  name: "Sarah Wijaya",
  email: "demo@greendiet.id",
  password: "password123",
  avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80",
  memberSince: "November 2026",
  isMember: true,
  isCloudUser: false,
  healthProfile: {
    age: 27,
    gender: "female",
    weight: 62, // kg
    height: 165, // cm
    activity: "moderate", // 1.55
    goal: "lose", // -500 kcal
    bmr: 1380,
    tdee: 2139,
    targetCalories: 1639,
    macros: {
      carbs: 184, // 45% (184g * 4 = 737 kcal)
      protein: 123, // 30% (123g * 4 = 492 kcal)
      fat: 45 // 25% (45g * 9 = 410 kcal)
    }
  }
};

class AuthManager {
  constructor() {
    this.currentUser = null;
    this.initUsersDatabase();
    this.loadSession();
  }

  // Inisialisasi basis data pengguna lokal jika belum ada
  initUsersDatabase() {
    try {
      const existing = localStorage.getItem(USERS_DB_KEY);
      if (!existing) {
        const initialUsers = [DEFAULT_DEMO_USER];
        localStorage.setItem(USERS_DB_KEY, JSON.stringify(initialUsers));
      }
    } catch (e) {
      console.warn("LocalStorage tidak tersedia:", e);
    }
  }

  // Muat sesi pengguna saat ini
  async loadSession() {
    try {
      // Periksa apakah Supabase Service siap dan ada session aktif di Supabase
      if (typeof supabaseService !== "undefined" && supabaseService.isConfigured) {
        const session = await supabaseService.getCurrentSession();
        if (session && session.user) {
          const profile = await supabaseService.getProfile(session.user.id);
          this.currentUser = {
            id: session.user.id,
            name: profile?.full_name || session.user.user_metadata?.full_name || session.user.email.split("@")[0],
            email: session.user.email,
            avatar: profile?.avatar_url || session.user.user_metadata?.avatar_url || `https://api.dicebear.com/7.x/adventurer/svg?seed=${session.user.id}`,
            memberSince: new Date(session.user.created_at).toLocaleDateString("id-ID", { month: "long", year: "numeric" }),
            isMember: true,
            isCloudUser: true,
            healthProfile: profile ? {
              age: profile.age,
              gender: profile.gender,
              weight: profile.weight,
              height: profile.height,
              activity: profile.activity,
              goal: profile.goal,
              bmr: profile.bmr,
              tdee: profile.tdee,
              targetCalories: profile.target_calories,
              macros: profile.macros
            } : { ...DEFAULT_DEMO_USER.healthProfile }
          };
          this.saveSession();
          this.notifyAuthChange();
          return;
        }
      }

      const stored = localStorage.getItem(AUTH_STORAGE_KEY);
      if (stored) {
        this.currentUser = JSON.parse(stored);
      } else {
        // Tidak login otomatis agar pengguna belum login melihat halaman Login
        this.currentUser = null;
      }
    } catch (e) {
      this.currentUser = null;
    }
    this.notifyAuthChange();
  }

  // Simpan sesi ke localStorage
  saveSession() {
    try {
      if (this.currentUser) {
        localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(this.currentUser));
      } else {
        localStorage.removeItem(AUTH_STORAGE_KEY);
      }
    } catch (e) {
      console.error("Gagal menyimpan sesi:", e);
    }
  }

  // Registrasi Member Baru (Cloud Supabase atau Lokal)
  async register(name, email, password, confirmPassword = "", healthData = null) {
    if (!name || !name.trim()) {
      return { success: false, message: "Nama lengkap wajib diisi." };
    }
    if (!email || !email.trim()) {
      return { success: false, message: "Alamat email wajib diisi." };
    }
    if (!password || password.length < 6) {
      return { success: false, message: "Kata sandi minimal harus 6 karakter." };
    }
    if (confirmPassword && password !== confirmPassword) {
      return { success: false, message: "Kata sandi dan konfirmasi kata sandi tidak cocok. Silakan periksa kembali." };
    }

    if (typeof supabaseService !== "undefined" && supabaseService.isConfigured) {
      const res = await supabaseService.register(email, password, name);
      if (!res.success) {
        return res;
      }

      if (res.user && res.session) {
        // Langsung buat profil di database Supabase
        const initialProfile = healthData || { ...DEFAULT_DEMO_USER.healthProfile };
        await supabaseService.upsertProfile(res.user.id, {
          name: name.trim(),
          email: email.trim(),
          avatar: `https://api.dicebear.com/7.x/adventurer/svg?seed=${res.user.id}`,
          ...initialProfile
        });

        this.currentUser = {
          id: res.user.id,
          name: name.trim(),
          email: email.trim().toLowerCase(),
          avatar: `https://api.dicebear.com/7.x/adventurer/svg?seed=${res.user.id}`,
          memberSince: new Date().toLocaleDateString("id-ID", { month: "long", year: "numeric" }),
          isMember: true,
          isCloudUser: true,
          healthProfile: initialProfile
        };

        this.saveSession();
        this.notifyAuthChange();
        // Inisialisasi meal plan & groceries baru untuk user ini di cloud
        if (typeof mealPlanner !== "undefined") {
          await mealPlanner.syncUserPlanWithCloud(res.user.id);
        }
        if (typeof groceryManager !== "undefined") {
          await groceryManager.syncUserGroceriesWithCloud(res.user.id);
        }

        return { success: true, user: this.currentUser, message: "Pendaftaran member Supabase berhasil!" };
      } else {
        return { success: true, user: null, message: res.message };
      }
    }

    // Fallback: Pendaftaran lokal
    try {
      const usersStr = localStorage.getItem(USERS_DB_KEY);
      const users = usersStr ? JSON.parse(usersStr) : [];

      const existing = users.find(u => u.email.toLowerCase() === email.toLowerCase());
      if (existing) {
        return { success: false, message: "Email sudah terdaftar. Silakan gunakan email lain atau login." };
      }

      const newUser = {
        id: "user_" + Date.now(),
        name: name.trim(),
        email: email.trim().toLowerCase(),
        password: password,
        avatar: `https://api.dicebear.com/7.x/adventurer/svg?seed=${encodeURIComponent(name)}`,
        memberSince: new Date().toLocaleDateString("id-ID", { month: "long", year: "numeric" }),
        isMember: true,
        isCloudUser: false,
        healthProfile: healthData || { ...DEFAULT_DEMO_USER.healthProfile }
      };

      users.push(newUser);
      localStorage.setItem(USERS_DB_KEY, JSON.stringify(users));

      this.currentUser = newUser;
      this.saveSession();
      this.notifyAuthChange();

      return { success: true, user: newUser, message: "Registrasi lokal berhasil! (Isi .env.local untuk menghubungkan ke Supabase Cloud)" };
    } catch (e) {
      return { success: false, message: "Terjadi kesalahan sistem saat registrasi: " + e.message };
    }
  }

  // Login Member (Cloud Supabase atau Lokal)
  async login(email, password) {
    if (!email || !email.trim()) {
      return { success: false, message: "Silakan masukkan alamat email Anda." };
    }
    if (!password) {
      return { success: false, message: "Silakan masukkan kata sandi Anda." };
    }

    if (typeof supabaseService !== "undefined" && supabaseService.isConfigured) {
      const res = await supabaseService.login(email, password);
      if (!res.success) {
        return res;
      }

      const user = res.user;
      const profile = await supabaseService.getProfile(user.id);

      this.currentUser = {
        id: user.id,
        name: profile?.full_name || user.user_metadata?.full_name || email.split("@")[0],
        email: user.email,
        avatar: profile?.avatar_url || user.user_metadata?.avatar_url || `https://api.dicebear.com/7.x/adventurer/svg?seed=${user.id}`,
        memberSince: new Date(user.created_at).toLocaleDateString("id-ID", { month: "long", year: "numeric" }),
        isMember: true,
        isCloudUser: true,
        healthProfile: profile ? {
          age: profile.age,
          gender: profile.gender,
          weight: profile.weight,
          height: profile.height,
          activity: profile.activity,
          goal: profile.goal,
          bmr: profile.bmr,
          tdee: profile.tdee,
          targetCalories: profile.target_calories,
          macros: profile.macros
        } : { ...DEFAULT_DEMO_USER.healthProfile }
      };

      this.saveSession();
      this.notifyAuthChange();

      // Sinkronkan meal plan dan grocery list pribadi milik user dari cloud
      if (typeof mealPlanner !== "undefined") {
        await mealPlanner.syncUserPlanWithCloud(user.id);
      }
      if (typeof groceryManager !== "undefined") {
        await groceryManager.syncUserGroceriesWithCloud(user.id);
      }

      return { success: true, user: this.currentUser, message: `Selamat datang kembali, ${this.currentUser.name}!` };
    }

    // Fallback: Login lokal
    try {
      const usersStr = localStorage.getItem(USERS_DB_KEY);
      const users = usersStr ? JSON.parse(usersStr) : [DEFAULT_DEMO_USER];

      const found = users.find(
        u => u.email.toLowerCase() === email.trim().toLowerCase() && u.password === password
      );

      if (found) {
        this.currentUser = found;
        this.saveSession();
        this.notifyAuthChange();
        return { success: true, user: found, message: `Selamat datang kembali, ${found.name}!` };
      } else {
        return { success: false, message: "Email atau kata sandi tidak cocok. Silakan coba lagi." };
      }
    } catch (e) {
      return { success: false, message: "Gagal memproses login: " + e.message };
    }
  }

  // Lupa Kata Sandi (Reset Password via Supabase Auth)
  async resetPassword(email) {
    if (typeof supabaseService !== "undefined" && supabaseService.isConfigured) {
      return await supabaseService.resetPassword(email);
    }
    return {
      success: false,
      message: "Fitur reset password via email memerlukan koneksi Supabase. Silakan isi kredensial di file .env.local terlebih dahulu."
    };
  }

  // Update Kata Sandi Baru
  async updatePassword(newPassword) {
    if (typeof supabaseService !== "undefined" && supabaseService.isConfigured) {
      return await supabaseService.updatePassword(newPassword);
    }
    return { success: false, message: "Koneksi Supabase belum aktif." };
  }

  // Masuk Sebagai Tamu (Guest Mode)
  loginAsGuest() {
    this.currentUser = {
      id: "guest_" + Date.now(),
      name: "Tamu Green Diet",
      email: "guest@greendiet.local",
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80",
      memberSince: "Mode Tamu",
      isMember: false,
      isCloudUser: false,
      healthProfile: { ...DEFAULT_DEMO_USER.healthProfile }
    };
    this.saveSession();
    this.notifyAuthChange();
    return { success: true, user: this.currentUser, message: "Masuk dalam mode tamu." };
  }

  // Keluar (Logout)
  async logout() {
    if (typeof supabaseService !== "undefined" && supabaseService.isConfigured) {
      await supabaseService.logout();
    }
    this.currentUser = null;
    this.saveSession();
    this.notifyAuthChange();

    // Reset meal plan dan groceries ke template bawaan
    if (typeof mealPlanner !== "undefined") {
      mealPlanner.resetToDefaultTemplate();
    }
    if (typeof groceryManager !== "undefined") {
      groceryManager.resetToDefault();
    }

    return { success: true, message: "Anda telah berhasil keluar." };
  }

  // Perbarui profil kesehatan pengguna aktif
  async updateHealthProfile(newProfile) {
    if (!this.currentUser) return;
    this.currentUser.healthProfile = {
      ...this.currentUser.healthProfile,
      ...newProfile
    };
    this.saveSession();

    // Jika member cloud Supabase, simpan ke database profiles di cloud
    if (this.currentUser.isCloudUser && typeof supabaseService !== "undefined" && supabaseService.isConfigured) {
      await supabaseService.upsertProfile(this.currentUser.id, {
        name: this.currentUser.name,
        email: this.currentUser.email,
        avatar: this.currentUser.avatar,
        ...newProfile
      });
    }

    // Simpan juga di database lokal
    try {
      const usersStr = localStorage.getItem(USERS_DB_KEY);
      if (usersStr) {
        const users = JSON.parse(usersStr);
        const idx = users.findIndex(u => u.id === this.currentUser.id);
        if (idx !== -1) {
          users[idx] = this.currentUser;
          localStorage.setItem(USERS_DB_KEY, JSON.stringify(users));
        }
      }
    } catch (e) {}

    this.notifyAuthChange();
  }

  notifyAuthChange() {
    window.dispatchEvent(new CustomEvent("greendiet_auth_changed", { detail: this.currentUser }));
  }

  isLoggedIn() {
    return this.currentUser !== null;
  }

  getUser() {
    return this.currentUser;
  }
}

const authManager = new AuthManager();
