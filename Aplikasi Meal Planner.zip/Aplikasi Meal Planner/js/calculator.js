/**
 * NutriPlan Green - Kalkulator Kebutuhan Kalori & Makronutrien (TDEE & BMR)
 * Menggunakan formula ilmiah Mifflin-St Jeor dengan pembagian makro presisi.
 */

class CalorieCalculator {
  constructor() {
    this.activityMultipliers = {
      sedentary: { factor: 1.2, label: "Sedentary (Jarang / Tidak Pernah Olahraga)" },
      light: { factor: 1.375, label: "Ringan (Olahraga 1-3 Hari / Minggu)" },
      moderate: { factor: 1.55, label: "Sedang (Olahraga 3-5 Hari / Minggu)" },
      active: { factor: 1.725, label: "Aktif (Olahraga Berat 6-7 Hari / Minggu)" },
      extra: { factor: 1.9, label: "Sangat Aktif (Latihan Fisik Berat / Atlet 2x Sehari)" }
    };

    this.goalAdjustments = {
      lose_fast: { delta: -750, label: "Turun Cepat (-750 kcal/hari)" },
      lose: { delta: -500, label: "Turun Sehat Ideal (-500 kcal/hari)" },
      maintain: { delta: 0, label: "Pertahankan Berat Badan (0 kcal)" },
      gain: { delta: 400, label: "Naikkan Berat / Massa Otot (+400 kcal/hari)" }
    };
  }

  // Hitung BMR (Basal Metabolic Rate) - Rumus Mifflin-St Jeor
  calculateBMR(gender, weightKg, heightCm, ageYears) {
    if (gender === "male") {
      return Math.round(10 * weightKg + 6.25 * heightCm - 5 * ageYears + 5);
    } else {
      return Math.round(10 * weightKg + 6.25 * heightCm - 5 * ageYears - 161);
    }
  }

  // Hitung BMI (Body Mass Index)
  calculateBMI(weightKg, heightCm) {
    const heightM = heightCm / 100;
    const bmi = +(weightKg / (heightM * heightM)).toFixed(1);

    let status = "Normal";
    let color = "text-emerald-600";
    let badgeBg = "bg-emerald-100 text-emerald-800";

    if (bmi < 18.5) {
      status = "Berat Kurang";
      color = "text-amber-500";
      badgeBg = "bg-amber-100 text-amber-800";
    } else if (bmi <= 24.9) {
      status = "Berat Ideal / Normal";
      color = "text-emerald-600";
      badgeBg = "bg-emerald-100 text-emerald-800";
    } else if (bmi <= 29.9) {
      status = "Kelebihan Berat Badan (Overweight)";
      color = "text-orange-500";
      badgeBg = "bg-orange-100 text-orange-800";
    } else {
      status = "Obesitas";
      color = "text-rose-600";
      badgeBg = "bg-rose-100 text-rose-800";
    }

    return { bmi, status, color, badgeBg };
  }

  // Hitung TDEE dan Pembagian Makro Lengkap
  computeFullProfile(params) {
    const { age, gender, weight, height, activity, goal } = params;

    const bmr = this.calculateBMR(gender, weight, height, age);
    const actFactor = this.activityMultipliers[activity]?.factor || 1.55;
    const tdee = Math.round(bmr * actFactor);

    const goalDelta = this.goalAdjustments[goal]?.delta ?? -500;
    // Pastikan batas kalori aman (minimal 1200 kcal wanita, 1400 kcal pria)
    const minSafeCalories = gender === "male" ? 1400 : 1200;
    const targetCalories = Math.max(minSafeCalories, Math.round(tdee + goalDelta));

    // Pembagian Makronutrien:
    // Karbohidrat: 45% kalori (4 kcal/g)
    // Protein: 30% kalori (4 kcal/g)
    // Lemak Sehat: 25% kalori (9 kcal/g)
    const carbCalories = targetCalories * 0.45;
    const proteinCalories = targetCalories * 0.30;
    const fatCalories = targetCalories * 0.25;

    const carbsGrams = Math.round(carbCalories / 4);
    const proteinGrams = Math.round(proteinCalories / 4);
    const fatGrams = Math.round(fatCalories / 9);

    const bmiInfo = this.calculateBMI(weight, height);

    return {
      age,
      gender,
      weight,
      height,
      activity,
      goal,
      bmr,
      tdee,
      targetCalories,
      bmi: bmiInfo.bmi,
      bmiStatus: bmiInfo.status,
      bmiColor: bmiInfo.color,
      bmiBadge: bmiInfo.badgeBg,
      macros: {
        carbs: carbsGrams,
        protein: proteinGrams,
        fat: fatGrams,
        percentages: { carbs: 45, protein: 30, fat: 25 }
      }
    };
  }
}

const calorieCalculator = new CalorieCalculator();
